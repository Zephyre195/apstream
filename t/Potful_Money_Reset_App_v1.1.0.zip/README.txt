POTFUL MONEY RESET APP — v1.1.0

1. Open START_HERE_Open_your_app.pdf.
2. On your phone: scan the QR code, then add the app to your home screen.
3. On a computer: double-click Potful_Money_Reset_App.html. It works offline.

Your data stays in your browser on that device. Use Settings → Download a backup now and then.
The spreadsheet version is in the other download (Potful_Money_Reset_v1.0.0.zip).

Planning aid, not regulated financial advice. Questions? Message Potful on Etsy.
