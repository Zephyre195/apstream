# Changelog

## 1.0.0 – 10 November 2026
First release: theme, optional fonts, nine widgets, offline demo, install, layout, data and security, and compatibility documents.
