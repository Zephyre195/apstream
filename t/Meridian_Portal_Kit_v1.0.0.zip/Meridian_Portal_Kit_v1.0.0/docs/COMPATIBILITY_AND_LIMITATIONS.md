# Compatibility and limitations

## Built for

* **ServiceNow Service Portal** (AngularJS widgets) and portals built on it. Uses standard widget fields and long-standing server APIs: `GlideRecordSecure`, `gs.getUser()`, `gs.getProperty()`, `$sp.getParameter()`, `$sp.getValue()`, `$sp.canReadRecord()` and `sn_sc.CatItem`.
* ES5 server scripts for global scope or scoped apps. Plain CSS (valid SCSS) using CSS custom properties.

## Tested for v1.0.0 (10 November 2026)

| Check | Result |
|---|---|
| 14 automated server-script tests (Node.js, with a stand-in for the ServiceNow APIs and fictional records): filters, access checks, limits, unsafe links, guests, property fallback, ES5-only, no writes | Passed |
| Full home page rendered in the offline AngularJS 1.8 + Bootstrap 3 demo as four user types | Passed, no script errors |
| Keyboard: skip link, tabs with arrow keys, Esc closes menus, visible focus | Passed |
| Layout at 390px and 1280–1440px | Passed |
| Automated accessibility scan (axe-core 4.14, WCAG 2.1 A and AA rules), all four user views | 0 violations |

## Not for

* UI Builder, Next Experience workspaces or Employee Center's own (non-Service Portal) pages.
* Rich text or HTML in options.

## Limitations

* Status board content is maintained by hand in options; it does not read an outage or CMDB table.
* My work shows requested items, incidents and approvals only. Other task types need a small server-script change.
* Greetings use the viewer's device time.
* Install in a sub-production instance first and review with your own data, ACLs and theme.
