# Install Meridian

**You need:** the `admin` or `sp_admin` role, a sub-production instance and an update set (or scoped app) to capture the work. Allow about 60 to 90 minutes.

## 1. Theme (required)

1. **Service Portal > Style Sheets > New.** Name: `mer-theme`. Paste `theme/mer-theme.css`. Save.
2. **Service Portal > Themes.** Open your portal's theme (or create one) and add `mer-theme` to **CSS Includes** (related list, order 100).
3. Optional fonts: create a second Style Sheet `mer-fonts`, paste `theme/mer-fonts.css`, save, then attach the seven `.woff2` files from `theme/fonts/` to that record. Replace each `ATTACHMENT_SYS_ID_...` with the matching attachment's sys_id (right-click the attachment > Copy sys_id, or open `sys_attachment` filtered by table `sp_css`). Add `mer-fonts` to CSS Includes with order 90. Without it, Meridian uses Segoe UI / system fonts and Georgia.
4. To rebrand, change the `--mer-...` colours at the top of `mer-theme.css`.

## 2. Widgets

For each folder in `widgets/`:

1. **Service Portal > Widgets > New.** Name it (e.g. `Meridian Hero search`) and set **ID** to the folder name (e.g. `mer-hero`). Save, then **Open in Widget Editor**.
2. Paste `1_body_html_template.html` into **HTML Template**, `2_css_scss.scss` into **CSS - SCSS**, `3_client_controller.js` into **Client Script** and `4_server_script.js` into **Server Script**, replacing the defaults. Save.
3. Open the widget record and paste `5_option_schema.json` into **Option schema**. Save.

The header and footer can be used two ways:

* **As page widgets** (simplest): put them at the top and bottom of each page and use instance options.
* **As the theme header and footer:** create them under **Service Portal > Headers & Footers** instead of Widgets (same fields), then pick them in your theme's **Header** and **Footer** fields. Theme headers have no instance options, so set them with system properties: create `meridian.header.brand_name`, `meridian.header.nav_json`, `meridian.footer.columns_json` etc. (any option name, prefixed `meridian.header.` or `meridian.footer.`). Instance options win when both exist.

## 3. Home page layout

Open your home page (often `index`) in **Service Portal Designer**:

| Container | Settings | Widgets |
|---|---|---|
| 1 | Width: **Fluid**, no padding | `mer-hero` |
| 2 | Width: **Fixed** | `mer-action-tiles` (keep **Overlap the hero** on) |
| 3 | Fixed, row with columns 8 / 4 | `mer-my-work` / `mer-service-status` |
| 4 | Fixed, 12 | `mer-catalog` |
| 5 | Fixed, row with columns 7 / 5 | `mer-knowledge` / `mer-help-cta` |

Put `mer-header` and `mer-footer` in fluid containers at the top and bottom if you are not using them as the theme header and footer. The widgets' own `.mer-wrap` keeps content to 1200px, so fluid containers look right.

Then open each instance's options (pencil icon) and fill them in. Copy values from `example_instance_options.json` to start.

## 4. Check

1. View the page as an admin: any configuration mistakes show as yellow **set-up notes** that only `admin` and `sp_admin` users see.
2. Impersonate an ordinary user with a few requests, and one with none. Check **My work**, the catalogue and articles show what that user may see.
3. Check with the keyboard only (Tab, Shift+Tab, Enter, arrow keys in the My work tabs, Esc to close menus) and at phone width.

## Remove

Remove the instances from pages (or delete them from `sp_instance`), delete the widgets and headers/footers, remove the Style Sheets from the theme's CSS Includes and delete them, and delete any `meridian.*` system properties. Nothing else is created.
