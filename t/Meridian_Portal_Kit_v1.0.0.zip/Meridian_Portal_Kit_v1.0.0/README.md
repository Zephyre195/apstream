# Meridian Portal Kit v1.0.0

A complete, original look for a **ServiceNow Service Portal** home page: a theme plus nine bespoke widgets that work together.

| Widget | ID | What it shows | Data |
|---|---|---|---|
| Header | `mer-header` | Brand, main navigation, account menu, skip link, mobile menu | Options or system properties |
| Hero search | `mer-hero` | Greeting, big search box, popular searches, one-line notice | Options |
| Action tiles | `mer-action-tiles` | Up to 6 large shortcut tiles overlapping the hero | Options |
| My work | `mer-my-work` | The user's open requests, issues and approvals in tabs | `sc_req_item`, `incident`, `sysapproval_approver` (read-only) |
| Catalogue showcase | `mer-catalog` | Catalogue items as cards with category filters | `sc_cat_item` (read-only) |
| Popular articles | `mer-knowledge` | Most-viewed published articles | `kb_knowledge` (read-only) |
| Service status | `mer-service-status` | A simple status board you edit in options | Options |
| Help panel | `mer-help-cta` | "Still need help?" with chat, phone and report buttons | Options |
| Footer | `mer-footer` | Brand, link columns and legal line | Options or system properties |

## Start here

1. Open `demo/index.html` in Chrome, Edge or Firefox. It runs offline with fictional data. Use the yellow bar to view the page as a busy user, a new starter, an admin or a guest.
2. Follow `docs/INSTALL.md`: theme first, then widgets, then the home page layout. Use a sub-production instance and an update set.
3. Configure each widget with `widgets/<id>/README.md` and `example_instance_options.json`.
4. Read `docs/DATA_AND_SECURITY.md` to see exactly which tables are read and how access is checked.

## What's in the box

```
theme/mer-theme.css          -> Style Sheet: colours, fonts, spacing (required)
theme/mer-fonts.css + fonts/ -> optional Fraunces and Manrope web fonts (SIL Open Font License)
widgets/<id>/1_ ... 5_       -> HTML template, CSS - SCSS, client script, server script, option schema
widgets/<id>/example_instance_options.json, README.md
demo/index.html              -> offline demo of the full home page
docs/                        -> install, page layout, data and security, compatibility, licence, support
Quick_Start.pdf, MANIFEST.txt
```

Independent product. Not affiliated with, endorsed by or certified by ServiceNow. ServiceNow is a trademark of ServiceNow, Inc.
