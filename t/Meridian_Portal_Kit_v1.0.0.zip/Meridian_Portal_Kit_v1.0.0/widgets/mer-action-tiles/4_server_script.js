(function () {
  /* Meridian Portal Kit | Action tiles | v1.0.0
     Large shortcut tiles for the most common tasks. Reads instance options only.
     No table queries, no writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  var notes = [];
  var TONES = ['teal', 'coral', 'sun', 'iris'];
  var ICONS = ['help', 'cart', 'laptop', 'key', 'user', 'book', 'chat', 'calendar', 'shield', 'chart', 'folder', 'link', 'spark', 'phone'];
  data.overlap = boolOpt(options.overlap_hero, true);
  data.heading = cleanText(options.heading, 80);
  data.tiles = [];
  var raw = readList(options.tiles_json, 'tiles_json', notes);
  for (var i = 0; i < raw.length; i++) {
    var t = raw[i] || {};
    if (data.tiles.length >= 6) { notes.push('Only the first 6 tiles are shown.'); break; }
    var label = cleanText(t.label, 40), url = safeUrl(t.url);
    if (!label || !url) { notes.push('Tile ' + (i + 1) + ' needs a label and a link starting with https://, / or ?id='); continue; }
    data.tiles.push({
      label: label, url: url, description: cleanText(t.description, 90),
      icon: ICONS.indexOf(t.icon) > -1 ? t.icon : 'link',
      tone: TONES.indexOf(t.tone) > -1 ? t.tone : TONES[data.tiles.length % TONES.length]
    });
  }
  data.config_error = notes.join(' ');
})();
