(function () {
  /* Meridian Portal Kit | Popular articles | v1.0.0
     Most-viewed published knowledge articles the user can read ($sp.canReadRecord, which applies ACLs and
     knowledge user criteria). Read-only. No writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  data.title = cleanText(options.title, 60) || 'Popular answers';
  data.limit = intOpt(options.limit, 5, 1, 10);
  data.all_url = '?id=' + pageId(options.knowledge_page, 'kb_view2');
  var articlePage = pageId(options.article_page, 'kb_article');
  var kb = cleanText(options.kb_id, 32);
  var gr = new GlideRecordSecure('kb_knowledge');
  gr.addQuery('workflow_state', 'published');
  if (kb) gr.addQuery('kb_knowledge_base', kb);
  gr.orderByDesc('sys_view_count');
  gr.setLimit(data.limit * 4);
  gr.query();
  data.articles = [];
  while (gr.next() && data.articles.length < data.limit) {
    if (!$sp.canReadRecord(gr)) continue;
    data.articles.push({
      title: cleanText(gr.getValue('short_description'), 120), category: cleanText(gr.getDisplayValue('kb_category'), 40),
      views: parseInt(gr.getValue('sys_view_count'), 10) || 0, updated: gr.getValue('sys_updated_on'),
      url: '?id=' + articlePage + '&sys_id=' + encodeURIComponent(gr.getUniqueValue())
    });
  }
})();
