(function () {
  /* Meridian Portal Kit | Help panel | v1.0.0
     "Still need help?" panel with up to 3 contact actions. Reads instance options only. No writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  var notes = [];
  var ICONS = ['help', 'chat', 'phone', 'calendar', 'book', 'link', 'spark', 'user'];
  data.title = cleanText(options.title, 60) || 'Still need help?';
  data.text = cleanText(options.text, 200);
  data.hours = cleanText(options.hours_text, 80);
  data.actions = [];
  var raw = readList(options.actions_json, 'actions_json', notes);
  for (var i = 0; i < raw.length && data.actions.length < 3; i++) {
    var a = raw[i] || {};
    var label = cleanText(a.label, 40), url = safeUrl(a.url);
    if (/^tel:\+?[0-9 ()\-]{3,20}$/.test(cleanText(a.url, 30))) url = cleanText(a.url, 30);
    if (!label || !url) { notes.push('Action ' + (i + 1) + ' needs a label and a link (https://, /, ?id= or tel:).'); continue; }
    data.actions.push({ label: label, url: url, icon: ICONS.indexOf(a.icon) > -1 ? a.icon : 'link', primary: data.actions.length === 0 });
  }
  data.config_error = notes.join(' ');
})();
