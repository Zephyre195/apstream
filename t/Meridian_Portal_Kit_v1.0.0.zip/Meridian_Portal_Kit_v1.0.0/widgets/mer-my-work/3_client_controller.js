api.controller = function ($scope, $element, $timeout) {
  /* Meridian Portal Kit | My work | v1.0.0 */
  var c = this;
  c.uid = Math.random().toString(36).slice(2, 8);
  c.active = 0;
  for (var i = 0; i < (c.data.tabs || []).length; i++) { if (c.data.tabs[i].count) { c.active = i; break; } }
  c.select = function (i, focus) {
    c.active = i;
    if (focus) $timeout(function () { var b = $element[0].querySelectorAll('[role=tab]')[i]; if (b) b.focus(); });
  };
  c.keys = function (e, i) {
    var n = c.data.tabs.length, k = e.key || '';
    if (k === 'ArrowRight' || e.keyCode === 39) { c.select((i + 1) % n, true); e.preventDefault(); }
    else if (k === 'ArrowLeft' || e.keyCode === 37) { c.select((i - 1 + n) % n, true); e.preventDefault(); }
    else if (k === 'Home' || e.keyCode === 36) { c.select(0, true); e.preventDefault(); }
    else if (k === 'End' || e.keyCode === 35) { c.select(n - 1, true); e.preventDefault(); }
  };
  c.tone = function (s) {
    s = String(s || '').toLowerCase();
    if (/resolved|complete|closed|approved|delivered/.test(s)) return 'success';
    if (/decision|approval|waiting|await|pending|hold|information/.test(s)) return 'warning';
    if (/reject|cancel|fail/.test(s)) return 'danger';
    return 'info';
  };
  c.ago = function (v) {
    if (!v) return '';
    var t = Date.parse(String(v).replace(' ', 'T') + 'Z');
    if (isNaN(t)) return '';
    var m = Math.round((Date.now() - t) / 60000);
    if (m < 1) return 'just now';
    if (m < 60) return m + ' min ago';
    var h = Math.round(m / 60);
    if (h < 24) return h + (h === 1 ? ' hour ago' : ' hours ago');
    var d = Math.round(h / 24);
    if (d < 30) return d + (d === 1 ? ' day ago' : ' days ago');
    return new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
  };
};
