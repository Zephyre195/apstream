(function () {
  /* Meridian Portal Kit | Catalogue showcase | v1.0.0
     Active catalogue items the user can see (user criteria via sn_sc.CatItem.canView, Service Portal visibility,
     and read ACLs via GlideRecordSecure). Read-only. No writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  var notes = [];
  data.title = cleanText(options.title, 60) || 'Request something';
  data.subtitle = cleanText(options.subtitle, 160);
  data.limit = intOpt(options.limit, 8, 1, 24);
  data.show_filters = boolOpt(options.show_filters, true);
  data.all_url = '?id=' + pageId(options.catalog_page, 'sc_home');
  var itemPage = pageId(options.item_page, 'sc_cat_item');
  var catalog = cleanText(options.catalog_id, 32) || cleanText($sp.getValue('sc_catalog'), 32);
  var ids = cleanText(options.item_ids, 2000);
  if (ids && !/^[0-9a-zA-Z_]+(,[0-9a-zA-Z_]+)*$/.test(ids.replace(/\s+/g, ''))) { notes.push('item_ids must be a comma-separated list of sys_ids.'); ids = ''; }
  ids = ids.replace(/\s+/g, '');

  var gr = new GlideRecordSecure('sc_cat_item');
  gr.addActiveQuery();
  if (catalog) gr.addQuery('sc_catalogs', 'CONTAINS', catalog);
  if (ids) gr.addQuery('sys_id', 'IN', ids);
  gr.orderBy('order');
  gr.orderBy('name');
  gr.setLimit(data.limit * 4);
  gr.query();
  data.items = [];
  var cats = {};
  data.categories = [];
  while (gr.next() && data.items.length < data.limit) {
    var id = gr.getUniqueValue();
    var ci = new sn_sc.CatItem(id);
    if (!ci.canView() || !ci.isVisibleServicePortal()) continue;
    var cat = cleanText(gr.getDisplayValue('category'), 40);
    if (cat && !cats[cat]) { cats[cat] = true; data.categories.push(cat); }
    data.items.push({
      name: cleanText(gr.getValue('name'), 80), description: cleanText(gr.getValue('short_description'), 140),
      category: cat, picture: cleanText(gr.getDisplayValue('picture'), 200),
      url: '?id=' + itemPage + '&sys_id=' + encodeURIComponent(id)
    });
  }
  if (ids) {
    var order = ids.split(',');
    data.items.sort(function (a, b) { return order.indexOf(a.url.split('sys_id=')[1]) - order.indexOf(b.url.split('sys_id=')[1]); });
  }
  if (!data.items.length) notes.push('No catalogue items matched. Check catalog_id, item_ids and that items are active and visible to this user.');
  data.config_error = notes.join(' ');
})();
