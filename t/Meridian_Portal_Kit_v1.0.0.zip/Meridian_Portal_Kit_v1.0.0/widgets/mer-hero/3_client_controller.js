api.controller = function ($scope, $location) {
  /* Meridian Portal Kit | Hero search | v1.0.0 */
  var c = this;
  var h = new Date().getHours();
  c.greeting = h < 12 ? 'Good morning' : (h < 18 ? 'Good afternoon' : 'Good evening');
  c.q = '';
  c.uid = Math.random().toString(36).slice(2, 8);
  c.search = function (term) {
    var q = String(term !== undefined ? term : (c.q || '')).trim();
    c.empty = !q;
    if (!q) return;
    $location.search({ id: c.data.search_page, spa: 1, q: q });
  };
};
