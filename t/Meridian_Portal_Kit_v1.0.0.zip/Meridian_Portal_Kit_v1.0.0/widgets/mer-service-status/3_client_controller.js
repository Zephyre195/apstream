api.controller = function () {
  /* Meridian Portal Kit | Service status | v1.0.0 */
  var c = this;
  c.uid = Math.random().toString(36).slice(2, 8);
};
