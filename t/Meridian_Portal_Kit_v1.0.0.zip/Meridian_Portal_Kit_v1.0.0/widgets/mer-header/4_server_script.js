(function () {
  /* Meridian Portal Kit | Header | v1.0.0
     Brand, main navigation and the signed-in user's menu. Reads instance options and the current user's name.
     No table queries, no writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  /* Used as a theme header/footer there are no instance options, so each option can also come from a
     system property named meridian.header.<option>, e.g. meridian.header.nav_json. */
  function pick(v, name) { return (v === undefined || v === null || v === '') ? gs.getProperty('meridian.header.' + name, '') : v; }
  var notes = [];
  data.brand_name = cleanText(pick(options.brand_name, 'brand_name'), 40) || 'Help Centre';
  data.logo_url = safeUrl(pick(options.logo_url, 'logo_url'));
  data.home_url = '?id=' + pageId(pick(options.home_page, 'home_page'), 'index');
  data.profile_url = '?id=' + pageId(pick(options.profile_page, 'profile_page'), 'user_profile');
  data.logout_url = safeUrl(pick(options.logout_url, 'logout_url')) || '/logout.do';
  data.login_url = '?id=' + pageId(pick(options.login_page, 'login_page'), 'login');
  var current = cleanText($sp.getParameter('id'), 80);
  data.nav = [];
  var raw = readList(pick(options.nav_json, 'nav_json'), 'nav_json', notes);
  for (var i = 0; i < raw.length && data.nav.length < 7; i++) {
    var l = raw[i] || {};
    var label = cleanText(l.label, 30), url = safeUrl(l.url);
    if (!label || !url) { notes.push('Navigation link ' + (i + 1) + ' needs a label and a link starting with https://, / or ?id='); continue; }
    var m = /[?&]id=([^&#]+)/.exec(url);
    data.nav.push({ label: label, url: url, active: !!(m && current && m[1] === current) });
  }
  data.user = null;
  if (gs.isLoggedIn()) {
    var u = gs.getUser();
    var first = cleanText(u.getFirstName(), 40), last = cleanText(u.getLastName(), 40);
    var full = cleanText(gs.getUserDisplayName(), 80);
    data.user = { first_name: first || full, initials: ((first.charAt(0) || '') + (last.charAt(0) || '')).toUpperCase() || full.charAt(0).toUpperCase() };
  }
  data.config_error = notes.join(' ');
})();
