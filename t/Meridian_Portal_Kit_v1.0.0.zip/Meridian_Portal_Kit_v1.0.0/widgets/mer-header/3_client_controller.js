api.controller = function ($scope, $element, $document) {
  /* Meridian Portal Kit | Header | v1.0.0 */
  var c = this;
  c.uid = Math.random().toString(36).slice(2, 8);
  c.navOpen = false;
  c.userOpen = false;
  function onKey(e) {
    if (e.key === 'Escape' || e.keyCode === 27) {
      if (c.userOpen || c.navOpen) {
        $scope.$apply(function () { c.userOpen = false; c.navOpen = false; });
        var btn = $element[0].querySelector('.mer-user__btn') || $element[0].querySelector('.mer-header__menu-btn');
        if (btn) btn.focus();
      }
    }
  }
  function onClick(e) {
    if (c.userOpen && !$element[0].querySelector('.mer-user').contains(e.target)) $scope.$apply(function () { c.userOpen = false; });
  }
  $document.on('keydown', onKey);
  $document.on('click', onClick);
  $scope.$on('$destroy', function () { $document.off('keydown', onKey); $document.off('click', onClick); });
};
