# Data dictionary

| Section | Fields | Checks |
|---|---|---|
| Specification | Name, direction, purpose, source, target, trigger, frequency, authentication approach, data classification, volumes, business owner, technical owner, support group | Name, purpose, trigger, authentication and all three owners required |
| Endpoints | ID, method, path, purpose, idempotent (Yes/No), duplicate protection, timeout | ID unique; method, path, timeout and idempotency required |
| Field mapping | Endpoint, source, target, type, required, default, transformation, example input, expected output | Known endpoint; target required and not mapped twice per endpoint; required targets need a source or default; transformations need both examples |
| Error handling | ID, category, endpoint (blank = all), retry (No retry / Retry with backoff / Manual retry), max retries, owner, agreed handling, alert | ID, category, handling and owner required; automatic retry on a non-idempotent endpoint needs duplicate protection; every rule needs a test that proves it |
| Tests | ID, scenario, endpoint, error rule, steps, expected, actual, evidence, defect, status | Scenario, steps and expected result required; endpoint and error rule must exist |
| Runbook | Symptom, check first, action, escalate to | Symptom, action and escalation required |

**Scenarios tracked for coverage:** Success, Invalid payload, Missing fields, Authentication, Permissions, Timeout, Duplicate request, Rate limiting, Partial failure, Malformed response, Server error, Reconciliation.

**Project file:** JSON with `app: "integration-qa"`, `spec`, `endpoints`, `mappings`, `errors`, `tests`, `runbook`. Imported files are validated and limited in size.
