# Support runbook (template)

## Contacts

| Role | Who |
| --- | --- |
| Business owner |  |
| Technical owner |  |
| Support group |  |

## Known problems

| Symptom | Check first | Action | Escalate to |
| --- | --- | --- | --- |
|  |  |  |  |

## Safe logging

* Log status codes, timings, record numbers and a hash of the response body.
* Never log credentials, tokens or full request or response bodies containing personal data.

## Reconciliation

Describe how source and target are compared, how often, and who resolves differences.
