# Integration specification (template)

> Fill in every row. Never include real credentials, keys or personal data.

## Overview

| Item | Detail |
| --- | --- |
| Integration name |  |
| Purpose |  |
| Direction |  |
| Source system |  |
| Target system |  |
| Trigger |  |
| Frequency and timing |  |
| Authentication approach (no secrets) |  |
| Data classification |  |
| Volumes |  |
| Business owner |  |
| Technical owner |  |
| Support group |  |

## Endpoints

| ID | Method | Path | Purpose | Idempotent | Duplicate protection | Timeout |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## Field mapping

| Endpoint | Source | Target | Type | Required | Default | Transformation | Example |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |  |

## Error handling

| ID | Category | Endpoint | Agreed handling | Retry | Max | Owner | Alert |
| --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |  |

## Sign-off

| Role | Name | Date |
| --- | --- | --- |
| Business owner |  |  |
| Technical owner |  |  |
| Support group |  |  |
