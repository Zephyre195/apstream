# Support runbook: Book courier shipments from requested items

> Worked example. All names and data are fictional.

## Contacts

| Role | Who |
| --- | --- |
| Business owner | Logistics Manager (Dana Price) |
| Technical owner | Integration Engineering (Ravi Patel) |
| Support group | Integration Support |

## Known problems

| Symptom | Check first | Action | Escalate to |
| --- | --- | --- | --- |
| Many requests show "Booking failed: 401" | Credential record expiry date; recent key rotation | Rotate the key with the carrier portal; update the credential record; re-trigger failed requests from the "Bookings to retry" list | Integration Engineering (Ravi Patel) |
| Bookings slow or timing out | Carrier status page; integration log for response times | If the carrier is degraded, pause the trigger and tell Logistics; otherwise raise with the carrier | Integration Support, then carrier support |
| Request shows booked but no tracking number after 2 hours | Status poll job last run; EP2 errors in the log | Run the status poll for that request; if 404, re-book using the same reference | Integration Support |
| Reconciliation report lists differences | Each line: does the request exist? was it cancelled? | Cancel orphan shipments with the carrier; re-book missing ones; record the outcome on the report | Logistics Manager |
| Malformed response tasks appear | Status code and body hash in the log; carrier API changelog | Compare with the agreed response; if the carrier changed it, raise a change to update the mapping | Integration Engineering |

## Safe logging

* Log status codes, timings, record numbers and a hash of the response body.
* Never log credentials, tokens or full request or response bodies containing personal data.

## Reconciliation

Daily report compares requested items marked as booked with shipments returned by the carrier for that day. Logistics resolves every difference and records the outcome.
