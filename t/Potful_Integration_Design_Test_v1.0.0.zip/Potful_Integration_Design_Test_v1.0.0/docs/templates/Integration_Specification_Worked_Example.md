# Integration specification: Book courier shipments from requested items

> Worked example. Northbeam Couriers and all data are fictional.

## Overview

| Item | Detail |
| --- | --- |
| Integration name | Book courier shipments from requested items |
| Purpose | When a hardware request is ready to ship, book a collection with Northbeam Couriers and keep the tracking status on the request. |
| Direction | Outbound |
| Source system | ServiceNow (Requested Item and fulfilment task) |
| Target system | Northbeam Couriers Shipments API v1 (fictional) |
| Trigger | Fulfilment task "Ship device" set to Ready to ship; status polled every 30 minutes until delivered |
| Frequency and timing | About 40 bookings a day, peaks of 150 on Mondays |
| Authentication approach (no secrets) | API key in the X-Api-Key header, stored in a credential record; rotated every 90 days |
| Data classification | Personal data: recipient name, phone and address. Keep to the minimum; never log full request bodies. |
| Volumes | Up to 150 bookings and 2,000 status checks a day |
| Business owner | Logistics Manager (Dana Price) |
| Technical owner | Integration Engineering (Ravi Patel) |
| Support group | Integration Support |

## Endpoints

| ID | Method | Path | Purpose | Idempotent | Duplicate protection | Timeout |
| --- | --- | --- | --- | --- | --- | --- |
| EP1 | POST | /v1/shipments | Book a collection | No | Idempotency-Key header = requested item sys_id | 15 seconds |
| EP2 | GET | /v1/shipments/{shipment_id} | Read status and tracking number | Yes |  | 10 seconds |
| EP3 | POST | /v1/shipments/{shipment_id}/cancel | Cancel a booking | Yes | Cancelling twice returns the same result | 10 seconds |

## Field mapping

| Endpoint | Source | Target | Type | Required | Default | Transformation | Example |
| --- | --- | --- | --- | --- | --- | --- | --- |
| EP1 | request_item.number | reference | string(40) | Yes |  |  |  |
| EP1 | request_item.requested_for.name | recipient.name | string(80) | Yes |  |  |  |
| EP1 | request_item.requested_for.mobile_phone | recipient.phone | E.164 string | Yes |  | Remove spaces; replace leading 0 with +44 | 07700 900123 → +447700900123 |
| EP1 | variables.delivery_street | address.line1 | string(100) | Yes |  |  |  |
| EP1 | variables.delivery_city | address.city | string(60) | Yes |  |  |  |
| EP1 | variables.delivery_postcode | address.postcode | UK postcode | Yes |  | Upper case, single space before the last 3 characters | sw1a1aa → SW1A 1AA |
| EP1 | variables.parcel_size | parcel.size | enum S/M/L | Yes |  | Small → S, Medium → M, Large → L | Medium → M |
| EP1 | variables.weight_kg | parcel.weight_grams | integer | Yes |  | Kilograms × 1000, rounded | 2.5 → 2500 |
| EP1 |  | service | enum | Yes | STANDARD |  |  |
| EP1 | task.expected_start | collection.date | date YYYY-MM-DD | Yes |  | Date part only, in the UK time zone | 2026-11-12 09:30:00 → 2026-11-12 |
| EP2 | tracking_number | request_item.u_tracking_number | string(30) | No |  |  |  |
| EP2 | status | request_item.u_courier_status | choice | Yes |  | booked → Booked, collected → In transit, delivered → Delivered, failed → Exception | collected → In transit |

## Error handling

| ID | Category | Endpoint | Agreed handling | Retry | Max | Owner | Alert |
| --- | --- | --- | --- | --- | --- | --- | --- |
| E01 | Validation error (400) | EP1 | Do not retry. Work note with the field errors; task to Logistics to correct the request. | No retry | 0 | Logistics | Task on the request |
| E02 | Authentication failed (401) | All | Stop all calls; alert the technical owner; follow the credential runbook. | No retry | 0 | Integration Engineering | P2 incident |
| E03 | Forbidden (403) | All | Treat as configuration error; incident to Integration Engineering. | No retry | 0 | Integration Engineering | P3 incident |
| E04 | Duplicate booking (409) | EP1 | Treat as success: read the existing shipment by reference and store its ID. | No retry | 0 | Integration Support | None |
| E05 | Rate limited (429) | All | Wait for Retry-After (or backoff 30s, 60s, 120s…) then try again. | Retry with backoff | 5 | Integration Support | After 5 failures |
| E06 | Timeout | EP1 | Retry with the same Idempotency-Key; the carrier returns the original booking if it was created. | Retry with backoff | 3 | Integration Support | After 3 failures |
| E07 | Server error (500/503) | All | Retry with backoff, then task to Integration Support. | Retry with backoff | 3 | Integration Support | Task after 3 failures |
| E08 | Malformed response | All | Do not mark as booked. Log status code and a body hash (not the body); task to Integration Support. | No retry | 0 | Integration Support | Task |
| E09 | Reconciliation mismatch | All | Daily report lists requests without a shipment and shipments without a request; Logistics resolves each one. | Manual retry |  | Logistics | Daily report |

## Sign-off

| Role | Name | Date |
| --- | --- | --- |
| Business owner |  |  |
| Technical owner |  |  |
| Support group |  |  |
