# Known limitations

* The app checks what you type. It doesn't call APIs or connect to ServiceNow.
* Designed around one outbound REST integration per project. Use one project per integration.
* The example Script Include is a teaching example. Its logic is unit-tested in Node.js with stand-ins for ServiceNow APIs; adapt it and test it in your own non-production instance before use.
* The mock API is for local testing only and keeps data in memory.
* Work is saved in the browser on the device you use. Clearing browser data removes it; use **Save file** regularly.
* Built and tested in Chromium-based browsers; other current browsers are expected to work.
