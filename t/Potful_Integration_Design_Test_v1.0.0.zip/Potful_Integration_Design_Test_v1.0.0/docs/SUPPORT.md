# Support

Message Potful through Etsy with your browser, what you expected and what happened (a screenshot helps). I usually reply within two working days. Help with defects and using the app is included; ServiceNow build or consulting work isn't. Fixes are released as new versions in your Etsy download.
