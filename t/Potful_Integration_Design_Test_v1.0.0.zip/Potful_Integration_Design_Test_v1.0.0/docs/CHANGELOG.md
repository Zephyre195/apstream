# Changelog

## 1.0.0 – 10 November 2026
First release: app with specification, endpoints, field mapping, error handling, tests with scenario coverage and suggestions, runbook, print / PDF, CSV exports and project files; worked courier example; mock API, Postman collection, example Script Include and tests; Markdown templates.
