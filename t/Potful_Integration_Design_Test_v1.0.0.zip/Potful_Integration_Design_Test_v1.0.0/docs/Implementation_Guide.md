# Implementation guide

1. **Specify.** Agree purpose, trigger, owners, support group, data classification and the authentication approach. Record where secrets are stored, never the secrets themselves.
2. **Endpoints.** For each call: method, path, timeout, and whether repeating it is safe. Calls that create records are usually not idempotent; agree duplicate protection (an idempotency key, or a reference the target rejects twice) before allowing automatic retries.
3. **Field mapping.** One row per target field. Required targets need a source or a default. Every transformation needs an example input and expected output; these become test data.
4. **Error handling.** For each failure category, agree the handling, retry rule, owner and alert. Typical: 4xx validation – no retry, fix data; 401/403 – stop and alert; 409 duplicate – treat as success; 429 – honour Retry-After; timeouts and 5xx – limited backoff, same idempotency key.
5. **Tests.** Write at least one test per scenario and link tests to the error rules they prove. Use **Suggest tests** for uncovered scenarios, then edit them to fit. Record results with evidence.
6. **Build in ServiceNow.** Typical pieces: a REST message or Script Include for the calls, a credential or protected property, a flow or scheduled job to trigger and retry, and fields on the record for the external ID and status. See `extras/servicenow` for a teaching example.
7. **Support.** Fill in the runbook: symptoms, what to check first, the fix and who to escalate to. Agree safe logging and the reconciliation routine.
8. **Hand over.** Use **Print / PDF** for review and sign-off. Keep the project file with the code.
