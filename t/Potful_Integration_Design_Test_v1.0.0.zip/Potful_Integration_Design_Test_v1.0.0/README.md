# Integration Design & Test v1.0.0

An offline app for specifying, checking and testing one outbound REST integration from ServiceNow, plus a complete worked example you can run on your own computer.

## Start in 2 minutes

1. Unzip, then double-click **Integration_Design_Test.html**. No internet, login or install.
2. Choose **See the worked example**: ServiceNow booking courier shipments with a fictional carrier (3 endpoints, 12 mapped fields, 9 error rules, 19 tests, 5 runbook entries).
3. Or start your own: fill in the **Specification**, then **Endpoints**, **Field mapping**, **Error handling**, **Tests** and **Support runbook**. Issues are flagged as you type, with a link to each field.
4. In **Tests and coverage**, see which of the 12 scenarios have a test, use **Suggest tests** for gaps, and record Pass, Fail or Blocked.
5. **Save file** keeps a project file; **Print / PDF** gives a review and handover pack; the CSV buttons export tests and the mapping.

## In this download

| Path | What it is |
|---|---|
| `Integration_Design_Test.html` | The app (one file, works offline) |
| `Worked_example_project.json` | The worked example as a project file |
| `Quick_Start.pdf` | One-page start guide |
| `docs/templates/` | Specification and runbook templates (Markdown), blank and completed |
| `extras/mock_api/` | Local mock of the fictional carrier API (Python 3.10+, no installs) |
| `extras/postman/` | Postman collection and environment for the mock (no secrets) |
| `extras/servicenow/` | Example Script Include and its Node.js tests |
| `docs/` | Implementation guide, data dictionary, known limitations, changelog, licence, support |

## Supported software

* App: current Microsoft Edge, Google Chrome, Firefox or Safari.
* Optional, for the runnable example: Python 3.10+, Postman or Newman 6, Node.js 18+.

Independent product. Not affiliated with, endorsed by or certified by ServiceNow or Postman. All example names, systems and data are fictional.
