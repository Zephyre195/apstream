/* Script Include: NorthbeamShipmentClient  (example for the fictional Northbeam Couriers API)
   Teaching example: adapt names, credentials and tables to your instance and test it in a
   non-production instance before use. ES5 so it runs in global scope or a scoped app.

   Prerequisites
   - A REST endpoint you are allowed to call (here the local mock API, or the vendor's sandbox).
   - The API key stored in a protected property (type password2) or a credential record. Never hard-code it.
   - Outbound calls run as the user who triggers them unless you run this from a flow or scheduled job.

   Design
   - buildPayload() maps and validates the requested item data (pure, easy to unit-test).
   - classify() turns an HTTP result into the agreed error rule (E01–E08) and next step.
   - book() makes ONE attempt. Retries are scheduled by the caller (flow wait or scheduled job),
     never with gs.sleep() loops. The Idempotency-Key stays the same across attempts. */
var NorthbeamShipmentClient = Class.create();
NorthbeamShipmentClient.prototype = {
  initialize: function (options) {
    options = options || {};
    this.baseUrl = options.baseUrl || gs.getProperty('northbeam.base_url', 'http://localhost:8085');
    this.apiKey = options.apiKey || gs.getProperty('northbeam.api_key', '');
    this.timeoutMs = options.timeoutMs || 15000;
    this.maxRetries = { E05: 5, E06: 3, E07: 3 };
  },

  /* data: { number, recipientName, mobile, street, city, postcode, parcelSize, weightKg, collectionDate } */
  buildPayload: function (data) {
    var errors = [];
    function req(v, field) { if (v === undefined || v === null || String(v).replace(/\s/g, '') === '') { errors.push(field + ' is missing'); return false; } return true; }
    var phone = '', postcode = '', size = '', grams = 0, date = '';
    if (req(data.mobile, 'Recipient phone')) {
      phone = String(data.mobile).replace(/[\s()-]/g, '');
      if (phone.charAt(0) === '0') phone = '+44' + phone.substring(1);
      if (!/^\+[1-9][0-9]{7,14}$/.test(phone)) errors.push('Recipient phone is not a valid number');
    }
    if (req(data.postcode, 'Postcode')) {
      var pc = String(data.postcode).toUpperCase().replace(/\s+/g, '');
      postcode = pc.length > 3 ? pc.substring(0, pc.length - 3) + ' ' + pc.substring(pc.length - 3) : pc;
      if (!/^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$/.test(postcode)) errors.push('Postcode is not a valid UK postcode');
    }
    if (req(data.parcelSize, 'Parcel size')) {
      size = { Small: 'S', Medium: 'M', Large: 'L' }[data.parcelSize] || '';
      if (!size) errors.push('Parcel size must be Small, Medium or Large');
    }
    if (req(data.weightKg, 'Weight')) {
      grams = Math.round(parseFloat(data.weightKg) * 1000);
      if (!(grams > 0 && grams <= 30000)) errors.push('Weight must be more than 0 and at most 30 kg');
    }
    if (req(data.collectionDate, 'Collection date')) date = String(data.collectionDate).substring(0, 10);
    req(data.number, 'Request number'); req(data.recipientName, 'Recipient name'); req(data.street, 'Street'); req(data.city, 'City');
    return {
      errors: errors,
      payload: errors.length ? null : {
        reference: String(data.number), service: 'STANDARD',
        recipient: { name: String(data.recipientName), phone: phone },
        address: { line1: String(data.street), city: String(data.city), postcode: postcode },
        parcel: { size: size, weight_grams: grams },
        collection: { date: date }
      }
    };
  },

  /* Returns { outcome: 'booked'|'duplicate'|'retry'|'fail', rule, retryInSeconds, shipmentId, message } */
  classify: function (status, body, headers, attempt) {
    var parsed = null;
    try { parsed = body ? JSON.parse(body) : null; } catch (e) { parsed = null; }
    attempt = attempt || 1;
    if ((status === 200 || status === 201) && parsed && parsed.shipment_id) return { outcome: 'booked', rule: '', shipmentId: parsed.shipment_id, tracking: parsed.tracking_number || '' };
    if (status === 200 || status === 201) return { outcome: 'fail', rule: 'E08', message: 'Unexpected response from the courier' };
    if (status === 409 && parsed && parsed.shipment_id) return { outcome: 'duplicate', rule: 'E04', shipmentId: parsed.shipment_id };
    if (status === 400) return { outcome: 'fail', rule: 'E01', message: 'Courier rejected the booking: ' + this._fieldList(parsed) };
    if (status === 401) return { outcome: 'fail', rule: 'E02', message: 'Courier authentication failed' };
    if (status === 403) return { outcome: 'fail', rule: 'E03', message: 'Courier refused access (configuration)' };
    var rule = status === 429 ? 'E05' : (status === 0 ? 'E06' : (status >= 500 ? 'E07' : ''));
    if (!rule) return { outcome: 'fail', rule: 'E08', message: 'Unexpected status ' + status };
    if (attempt > this.maxRetries[rule]) return { outcome: 'fail', rule: rule, message: 'Gave up after ' + (attempt - 1) + ' retries' };
    var after = parseInt((headers && (headers['Retry-After'] || headers['retry-after'])) || '', 10);
    return { outcome: 'retry', rule: rule, retryInSeconds: !isNaN(after) && after > 0 ? after : 30 * Math.pow(2, attempt - 1) };
  },

  /* One attempt. idempotencyKey: use the requested item's sys_id so retries never double-book. */
  book: function (data, idempotencyKey, attempt) {
    var built = this.buildPayload(data);
    if (built.errors.length) return { outcome: 'fail', rule: 'E01', message: built.errors.join('; '), sent: false };
    var r = new sn_ws.RESTMessageV2();
    r.setEndpoint(this.baseUrl + '/v1/shipments');
    r.setHttpMethod('post');
    r.setRequestHeader('Content-Type', 'application/json');
    r.setRequestHeader('Accept', 'application/json');
    r.setRequestHeader('X-Api-Key', this.apiKey);
    r.setRequestHeader('Idempotency-Key', String(idempotencyKey));
    r.setHttpTimeout(this.timeoutMs);
    r.setRequestBody(JSON.stringify(built.payload));
    var res = r.execute();
    var status = res.haveError() && !res.getStatusCode() ? 0 : res.getStatusCode();
    var result = this.classify(status, res.getBody(), { 'Retry-After': res.getHeader('Retry-After') }, attempt || 1);
    result.sent = true;
    return result;
  },

  _fieldList: function (parsed) {
    if (!parsed || !parsed.errors || !parsed.errors.length) return 'no details';
    var out = [];
    for (var i = 0; i < parsed.errors.length && i < 10; i++) out.push(parsed.errors[i].field);
    return out.join(', ');
  },

  type: 'NorthbeamShipmentClient'
};
