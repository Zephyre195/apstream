/* Node.js 18+ tests for the example Script Include, with stand-ins for Class, gs and sn_ws.RESTMessageV2.
   Run: node NorthbeamShipmentClient.test.js */
const fs = require('fs'), path = require('path'), vm = require('vm'), assert = require('assert');
const calls = [];
let next = { status: 201, body: '{"shipment_id":"SHP-1","tracking_number":"NB1"}', headers: {}, error: false };
class RESTMessageV2 {
  constructor() { this.h = {}; }
  setEndpoint(u) { this.url = u; } setHttpMethod(m) { this.m = m; } setRequestHeader(k, v) { this.h[k] = v; } setHttpTimeout(t) { this.t = t; } setRequestBody(b) { this.b = b; }
  execute() { calls.push(this); const n = next; return { getStatusCode: () => n.status, getBody: () => n.body, getHeader: k => n.headers[k] || null, haveError: () => n.error }; }
}
const ctx = { Class: { create: () => function () { this.initialize.apply(this, arguments); } }, gs: { getProperty: (k, d) => d }, sn_ws: { RESTMessageV2 } };
vm.createContext(ctx); vm.runInContext(fs.readFileSync(path.join(__dirname, 'NorthbeamShipmentClient.js'), 'utf8'), ctx);
const C = new ctx.NorthbeamShipmentClient({ apiKey: 'demo-key' });
const good = { number: 'RITM0020114', recipientName: 'Alex Morgan', mobile: '07700 900123', street: '1 Example Street', city: 'London', postcode: 'sw1a1aa', parcelSize: 'Medium', weightKg: '2.5', collectionDate: '2026-11-12 09:30:00' };
let n = 0; const test = (name, fn) => { try { fn(); n++; console.log('ok  ' + name); } catch (e) { console.log('FAIL ' + name + '\n  ' + e.message); process.exitCode = 1; } };
test('mapping matches the worked examples', () => {
  const p = C.buildPayload(good).payload;
  assert.strictEqual(p.recipient.phone, '+447700900123'); assert.strictEqual(p.address.postcode, 'SW1A 1AA');
  assert.strictEqual(p.parcel.size, 'M'); assert.strictEqual(p.parcel.weight_grams, 2500); assert.strictEqual(p.collection.date, '2026-11-12'); assert.strictEqual(p.service, 'STANDARD');
});
test('missing and invalid fields stop the call (IT-05, IT-19)', () => {
  calls.length = 0;
  const r = C.book(Object.assign({}, good, { mobile: '' }), 'k1', 1); assert.strictEqual(r.sent, false); assert.strictEqual(r.rule, 'E01'); assert.ok(/phone is missing/.test(r.message));
  assert.ok(C.buildPayload(Object.assign({}, good, { weightKg: '0' })).errors.some(e => /Weight/.test(e)));
  assert.ok(C.buildPayload(Object.assign({}, good, { postcode: 'NOT A CODE' })).errors.some(e => /Postcode/.test(e)));
  assert.strictEqual(calls.length, 0);
});
test('book sends headers, timeout and idempotency key; no key in body', () => {
  calls.length = 0; next = { status: 201, body: '{"shipment_id":"SHP-9","tracking_number":"NB9"}', headers: {} };
  const r = C.book(good, 'sysid123', 1); const c = calls[0];
  assert.strictEqual(r.outcome, 'booked'); assert.strictEqual(r.shipmentId, 'SHP-9');
  assert.strictEqual(c.h['Idempotency-Key'], 'sysid123'); assert.strictEqual(c.h['X-Api-Key'], 'demo-key'); assert.strictEqual(c.t, 15000); assert.ok(!/demo-key/.test(c.b));
});
test('error classification matches the error matrix', () => {
  assert.strictEqual(C.classify(400, '{"errors":[{"field":"address.postcode"}]}').rule, 'E01');
  assert.strictEqual(C.classify(401, '').rule, 'E02'); assert.strictEqual(C.classify(403, '').rule, 'E03');
  const d = C.classify(409, '{"shipment_id":"SHP-1"}'); assert.strictEqual(d.outcome, 'duplicate'); assert.strictEqual(d.shipmentId, 'SHP-1');
  assert.strictEqual(C.classify(200, '<html>').rule, 'E08'); assert.strictEqual(C.classify(201, '{"ok":true}').rule, 'E08');
});
test('retries: Retry-After respected, backoff, then give up', () => {
  assert.deepStrictEqual([C.classify(429, '', { 'Retry-After': '2' }, 1).retryInSeconds, C.classify(500, '', {}, 1).retryInSeconds, C.classify(500, '', {}, 3).retryInSeconds], [2, 30, 120]);
  assert.strictEqual(C.classify(429, '', {}, 6).outcome, 'fail'); assert.strictEqual(C.classify(503, '', {}, 4).outcome, 'fail'); assert.strictEqual(C.classify(0, '', {}, 2).rule, 'E06');
  calls.length = 0; next = { status: 0, body: '', headers: {}, error: true };
  assert.strictEqual(C.book(good, 'same-key', 1).outcome, 'retry');
});
console.log('\n' + n + ' tests passed');
