# Running the worked example

Everything here runs on your own computer against a fictional API. Nothing connects to ServiceNow or a real carrier.

## 1. Start the mock API

```
python mock_api/northbeam_mock.py
```

It listens on `http://localhost:8085` (pass another port as an argument). Keys: `demo-key` (full access) and `readonly-key` (read only). Force failures with the header `X-Mock-Scenario: timeout | server_error | unavailable | rate_limit | malformed | missing_status`. Data is kept in memory only.

## 2. Run the Postman collection

* **Postman:** import `postman/Northbeam_mock.postman_collection.json` and `postman/Local_mock.postman_environment.json`, choose the *Local mock* environment and run the collection.
* **Newman (command line):** `npx newman run postman/Northbeam_mock.postman_collection.json -e postman/Local_mock.postman_environment.json`

Expected: 16 requests, 18 assertions, 0 failures, covering success, invalid payload, missing fields, authentication, permissions, idempotent retry, duplicate, rate limiting, malformed responses, server errors and cancellation.

## 3. Run the Script Include tests

```
node servicenow/NorthbeamShipmentClient.test.js
```

Expected: 5 tests passed. The tests use stand-ins for `Class`, `gs` and `sn_ws.RESTMessageV2`, so they check the mapping, error classification, retry and idempotency logic, not a live instance.

## Using the example code in ServiceNow

`servicenow/NorthbeamShipmentClient.js` is a teaching example. To try it in a **non-production** instance:

1. Create a Script Include named `NorthbeamShipmentClient` (client callable off) and paste the file.
2. Create system properties `northbeam.base_url` and `northbeam.api_key` (type *password2*), or use a credential record.
3. Call it from a flow action or scheduled job; schedule retries with a wait rather than looping in script.
4. Your instance must be able to reach the API. A mock on your laptop isn't reachable from a cloud instance; use a MID Server or the vendor's sandbox.
