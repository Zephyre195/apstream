#!/usr/bin/env python3
"""Northbeam Couriers mock API (fictional) for the worked example. Python 3.10+, standard library only.

Run:   python northbeam_mock.py            (listens on http://localhost:8085)
Keys:  demo-key (full access), readonly-key (GET only). Anything else returns 401.
Force a scenario with the header  X-Mock-Scenario: timeout | server_error | unavailable | rate_limit | malformed | missing_status
Data is kept in memory and cleared when you stop the server. Local testing only: never expose it to a network.
"""
import json, re, sys, time, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8085
KEYS = {'demo-key': 'full', 'readonly-key': 'read'}
SHIPMENTS, BY_REF, BY_IDEM = {}, {}, {}
POSTCODE = re.compile(r'^[A-Z]{1,2}[0-9][A-Z0-9]? [0-9][A-Z]{2}$')
PHONE = re.compile(r'^\+[1-9][0-9]{7,14}$')
DATE = re.compile(r'^\d{4}-\d{2}-\d{2}$')


def validate(b):
    errs = []
    def need(path, ok=lambda v: v not in (None, '')):
        cur = b
        for p in path.split('.'):
            cur = cur.get(p) if isinstance(cur, dict) else None
        if not ok(cur):
            errs.append({'field': path, 'message': 'missing or invalid'})
    need('reference'); need('recipient.name')
    need('recipient.phone', lambda v: isinstance(v, str) and bool(PHONE.match(v)))
    need('address.line1'); need('address.city')
    need('address.postcode', lambda v: isinstance(v, str) and bool(POSTCODE.match(v)))
    need('parcel.size', lambda v: v in ('S', 'M', 'L'))
    need('parcel.weight_grams', lambda v: isinstance(v, int) and 0 < v <= 30000)
    need('service', lambda v: v in ('STANDARD', 'EXPRESS'))
    need('collection.date', lambda v: isinstance(v, str) and bool(DATE.match(v)))
    return errs


class H(BaseHTTPRequestHandler):
    server_version = 'NorthbeamMock/1.0'

    def log_message(self, fmt, *args):  # keep output short; never print request bodies
        sys.stderr.write('%s %s\n' % (self.command, self.path))

    def send(self, code, body=None, headers=None, raw=None):
        data = raw if raw is not None else json.dumps(body or {}).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'text/html' if raw is not None else 'application/json')
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def pre(self, write):
        scen = self.headers.get('X-Mock-Scenario', '')
        if scen == 'timeout':
            time.sleep(20)
        if scen == 'server_error':
            return self.send(500, {'error': 'internal_error'}) or True
        if scen == 'unavailable':
            return self.send(503, {'error': 'unavailable'}, {'Retry-After': '2'}) or True
        if scen == 'rate_limit':
            return self.send(429, {'error': 'rate_limited'}, {'Retry-After': '2'}) or True
        if scen == 'malformed':
            return self.send(200, raw=b'<html><body>Gateway page</body></html>') or True
        role = KEYS.get(self.headers.get('X-Api-Key', ''))
        if not role:
            return self.send(401, {'error': 'unauthorised'}) or True
        if write and role != 'full':
            return self.send(403, {'error': 'forbidden'}) or True
        return False

    def do_GET(self):
        if self.path == '/health':
            return self.send(200, {'status': 'ok'})
        if self.pre(False):
            return
        m = re.fullmatch(r'/v1/shipments/([\w-]+)', self.path)
        if not m or m.group(1) not in SHIPMENTS:
            return self.send(404, {'error': 'not_found'})
        s = dict(SHIPMENTS[m.group(1)])
        if self.headers.get('X-Mock-Scenario') == 'missing_status':
            s.pop('status', None)
        return self.send(200, s)

    def do_POST(self):
        if self.pre(True):
            return
        n = int(self.headers.get('Content-Length') or 0)
        if n > 100_000:
            return self.send(413, {'error': 'too_large'})
        raw = self.rfile.read(n) if n else b''
        m = re.fullmatch(r'/v1/shipments/([\w-]+)/cancel', self.path)
        if m:
            s = SHIPMENTS.get(m.group(1))
            if not s:
                return self.send(404, {'error': 'not_found'})
            s['status'] = 'cancelled'
            return self.send(200, s)
        if self.path != '/v1/shipments':
            return self.send(404, {'error': 'not_found'})
        try:
            body = json.loads(raw or b'{}')
            assert isinstance(body, dict)
        except Exception:
            return self.send(400, {'error': 'invalid_json'})
        idem = self.headers.get('Idempotency-Key')
        if idem and idem in BY_IDEM:
            return self.send(200, SHIPMENTS[BY_IDEM[idem]])
        errs = validate(body)
        if errs:
            return self.send(400, {'error': 'validation_failed', 'errors': errs})
        if body['reference'] in BY_REF:
            return self.send(409, {'error': 'duplicate_reference', 'shipment_id': BY_REF[body['reference']]})
        sid = 'SHP-' + uuid.uuid4().hex[:8].upper()
        s = {'shipment_id': sid, 'reference': body['reference'], 'status': 'booked', 'tracking_number': 'NB' + uuid.uuid4().hex[:10].upper()}
        SHIPMENTS[sid] = s; BY_REF[body['reference']] = sid
        if idem:
            BY_IDEM[idem] = sid
        return self.send(201, s)


if __name__ == '__main__':
    print('Northbeam mock API (fictional) on http://localhost:%d  (Ctrl+C to stop)' % PORT)
    ThreadingHTTPServer(('127.0.0.1', PORT), H).serve_forever()
