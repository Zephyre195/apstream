# Data and security

Meridian never writes data, never calls external services and never renders HTML from options or records (everything is shown as text by AngularJS). Links from options must start with `https://`, `http://`, `/` (not `//`) or `?`; the help panel also accepts `tel:`.

## What each widget reads

| Widget | Table | Filter | Access check |
|---|---|---|---|
| My work: Requests | `sc_req_item` | `request.requested_for` = current user, active, newest first | `GlideRecordSecure` (read ACLs) |
| My work: Issues | `incident` | `caller_id` = current user, active | `GlideRecordSecure` |
| My work: Approvals | `sysapproval_approver` | `approver` = current user, state = requested | `GlideRecordSecure` |
| Catalogue showcase | `sc_cat_item` | active, in the portal's catalogue (or `catalog_id`), optional hand-picked sys_ids, by order then name | `GlideRecordSecure`, then `sn_sc.CatItem.canView()` (user criteria) and `isVisibleServicePortal()` |
| Popular articles | `kb_knowledge` | workflow state published, optional knowledge base, most viewed first | `GlideRecordSecure`, then `$sp.canReadRecord()` |

Header, hero, tiles, status, help panel and footer read only their options (and, for the header and footer, `meridian.*` system properties), plus the user's name.

## Performance

* My work counts at most 100 records per tab and returns up to 10 rows.
* The catalogue and articles widgets fetch at most four times the number they show, then filter by access.
* No widget polls or refreshes on its own.

## Guests

When nobody is signed in, My work shows a sign-in message and runs no queries; the header shows **Sign in**.

## Things to check on your instance

* Your requests list may use a different "requested for" field if you have customised requests; change the `addQuery` line in `mer-my-work` if so.
* If your page IDs differ from the defaults (`ticket`, `approval`, `sc_cat_item`, `kb_article`, `search`...), set them in each widget's options.
