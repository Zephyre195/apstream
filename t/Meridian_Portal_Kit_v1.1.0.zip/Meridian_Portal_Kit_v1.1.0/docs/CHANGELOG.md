# Changelog

## 1.1.0 – 10 November 2026
* New optional **Platform** style (`theme/mer-preset-platform.css`): cool blues and greens with sans-serif headings.
* More colours are theme settings (hero gradient, help panel, accent text colours, heading weight).
* Demo: switch between Platform and Meridian styles.

## 1.0.0 – 10 November 2026
First release: theme, optional fonts, nine widgets, offline demo, install, layout, data and security, and compatibility documents.
