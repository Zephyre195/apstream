# Support

**Included:** fixes for defects in these files, and help understanding the documentation. Message Potful on Etsy with the widget ID, your ServiceNow release, what you expected and what happened (a screenshot helps). I usually reply within two working days.

**Not included:** customising the kit for your organisation, new features, implementation on your instance, or problems caused by other customisations.

**Updates:** fixes are released as new versions in your Etsy download (see CHANGELOG.md).
