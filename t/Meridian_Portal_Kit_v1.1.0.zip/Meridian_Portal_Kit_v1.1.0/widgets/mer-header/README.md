# Header (`mer-header`)

Brand, main navigation and the account menu. Includes a skip link and a mobile menu.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `brand_name` | string | Help Centre | Shown next to the logo, up to 40 characters |
| `logo_url` | string | – | Optional. /your_logo.png or https://... Leave blank to use the Meridian mark |
| `nav_json` | string | – | Array of {"label", "url"}. Up to 7 links |
| `home_page` | string | index | Portal page the brand links to |
| `profile_page` | string | user_profile |  |
| `login_page` | string | login | Shown to people who are not signed in |
| `logout_url` | string | /logout.do |  |

## How it behaves

* `nav_json`: up to 7 links. The link whose `?id=` matches the current page is highlighted and marked `aria-current="page"`.
* The account button shows the user's initials and first name; Esc or clicking elsewhere closes the menu.
* As a theme header there are no instance options: set `meridian.header.<option>` system properties instead (see INSTALL.md).

## Example options

Fictional values you can paste into the instance options and edit.

```json
{
  "brand_name": "Help Centre",
  "nav_json": "[{\"label\":\"Home\",\"url\":\"?id=index\"},{\"label\":\"Request something\",\"url\":\"?id=sc_home\"},{\"label\":\"Knowledge\",\"url\":\"?id=kb_view2\"},{\"label\":\"My requests\",\"url\":\"?id=requests\"}]"
}
```
