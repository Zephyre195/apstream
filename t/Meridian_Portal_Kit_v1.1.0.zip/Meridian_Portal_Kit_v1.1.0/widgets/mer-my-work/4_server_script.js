(function () {
  /* Meridian Portal Kit | My work | v1.1.0
     The signed-in user's open requests, incidents and approvals.
     Read-only. Uses GlideRecordSecure so the user's normal read ACLs apply. No writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  var MAX_COUNT = 99;
  data.title = cleanText(options.title, 60) || 'My work';
  data.limit = intOpt(options.limit, 5, 1, 10);
  var ticketPage = pageId(options.ticket_page, 'ticket');
  var approvalPage = pageId(options.approval_page, 'approval');
  data.tabs = [];
  data.signed_in = gs.isLoggedIn();
  if (!data.signed_in) return;
  var me = gs.getUserID();

  function collect(gr, mapRow) {
    var out = { items: [], count: 0 };
    gr.query();
    while (gr.next()) {
      out.count++;
      if (out.items.length < data.limit) out.items.push(mapRow(gr));
      if (out.count > MAX_COUNT) break;
    }
    return out;
  }
  function link(table, id) { return '?id=' + ticketPage + '&table=' + table + '&sys_id=' + encodeURIComponent(id); }

  if (boolOpt(options.show_requests, true)) {
    var ri = new GlideRecordSecure('sc_req_item');
    ri.addQuery('request.requested_for', me);
    ri.addActiveQuery();
    ri.orderByDesc('sys_updated_on');
    var r = collect(ri, function (g) {
      return { number: g.getValue('number'), title: cleanText(g.getDisplayValue('cat_item') || g.getValue('short_description'), 90),
        status: cleanText(g.getDisplayValue('stage') || g.getDisplayValue('state'), 40), updated: g.getValue('sys_updated_on'), url: link('sc_req_item', g.getUniqueValue()) };
    });
    data.tabs.push({ key: 'requests', label: 'Requests', count: r.count, items: r.items, all_url: '?id=' + pageId(options.requests_page, 'requests'),
      empty: 'No open requests. Anything you ask for will show here.' });
  }
  if (boolOpt(options.show_incidents, true)) {
    var inc = new GlideRecordSecure('incident');
    inc.addQuery('caller_id', me);
    inc.addActiveQuery();
    inc.orderByDesc('sys_updated_on');
    var n = collect(inc, function (g) {
      return { number: g.getValue('number'), title: cleanText(g.getValue('short_description'), 90),
        status: cleanText(g.getDisplayValue('state'), 40), updated: g.getValue('sys_updated_on'), url: link('incident', g.getUniqueValue()) };
    });
    data.tabs.push({ key: 'incidents', label: 'Issues', count: n.count, items: n.items, all_url: '?id=' + pageId(options.requests_page, 'requests'),
      empty: 'No open issues. Nice.' });
  }
  if (boolOpt(options.show_approvals, true)) {
    var ap = new GlideRecordSecure('sysapproval_approver');
    ap.addQuery('approver', me);
    ap.addQuery('state', 'requested');
    ap.orderByDesc('sys_updated_on');
    var a = collect(ap, function (g) {
      return { number: cleanText(g.getDisplayValue('sysapproval'), 40), title: cleanText(g.getDisplayValue('source_table'), 60) || 'Approval',
        status: 'Needs your decision', updated: g.getValue('sys_updated_on'), url: '?id=' + approvalPage + '&sys_id=' + encodeURIComponent(g.getUniqueValue()) };
    });
    data.tabs.push({ key: 'approvals', label: 'Approvals', count: a.count, items: a.items, all_url: '?id=' + pageId(options.approvals_page, 'approvals'),
      empty: 'Nothing is waiting for your approval.' });
  }
  for (var i = 0; i < data.tabs.length; i++) data.tabs[i].count_label = data.tabs[i].count > MAX_COUNT ? MAX_COUNT + '+' : String(data.tabs[i].count);
})();
