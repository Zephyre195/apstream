# My work (`mer-my-work`)

The signed-in user's open requests, issues and approvals, in keyboard-friendly tabs with counts.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `title` | string | My work |  |
| `limit` | integer | 5 | 1 to 10 |
| `show_requests` | boolean | true | Open requested items (sc_req_item) requested for the user |
| `show_incidents` | boolean | true | Open incidents where the user is the caller |
| `show_approvals` | boolean | true | Approvals waiting for the user |
| `ticket_page` | string | ticket | Opens ?id=<page>&table=...&sys_id=... |
| `approval_page` | string | approval | Opens ?id=<page>&sys_id=... |
| `requests_page` | string | requests |  |
| `approvals_page` | string | approvals |  |

## How it behaves

* Reads `sc_req_item`, `incident` and `sysapproval_approver` with `GlideRecordSecure`. See DATA_AND_SECURITY.md.
* Opens on the first tab that has something in it. Arrow keys, Home and End move between tabs.
* Status pills are coloured by keywords in the state or stage (e.g. "Waiting" = amber, "Complete" = green).
* Guests see a sign-in message and no queries run.

## Example options

Fictional values you can paste into the instance options and edit.

```json
{}
```
