api.controller = function () {
  /* Meridian Portal Kit | Footer | v1.1.0 */
  var c = this;
  c.year = new Date().getFullYear();
};
