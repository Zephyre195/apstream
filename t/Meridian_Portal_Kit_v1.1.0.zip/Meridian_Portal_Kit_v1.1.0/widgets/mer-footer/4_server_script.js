(function () {
  /* Meridian Portal Kit | Footer | v1.1.0
     Link columns and a legal line. Reads instance options only. No writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  /* Used as a theme header/footer there are no instance options, so each option can also come from a
     system property named meridian.footer.<option>, e.g. meridian.footer.columns_json. */
  function pick(v, name) { return (v === undefined || v === null || v === '') ? gs.getProperty('meridian.footer.' + name, '') : v; }
  var notes = [];
  data.brand_name = cleanText(pick(options.brand_name, 'brand_name'), 40) || 'Help Centre';
  data.tagline = cleanText(pick(options.tagline, 'tagline'), 140);
  data.legal = cleanText(pick(options.legal_text, 'legal_text'), 160);
  data.columns = [];
  var raw = readList(pick(options.columns_json, 'columns_json'), 'columns_json', notes);
  for (var i = 0; i < raw.length && data.columns.length < 4; i++) {
    var col = raw[i] || {};
    var heading = cleanText(col.heading, 40);
    var links = [];
    var src = Object.prototype.toString.call(col.links) === '[object Array]' ? col.links : [];
    for (var j = 0; j < src.length && links.length < 8; j++) {
      var l = src[j] || {};
      var label = cleanText(l.label, 40), url = safeUrl(l.url);
      if (label && url) links.push({ label: label, url: url }); else notes.push('A link in column ' + (i + 1) + ' needs a label and a valid link.');
    }
    if (heading && links.length) data.columns.push({ heading: heading, links: links });
  }
  data.config_error = notes.join(' ');
})();
