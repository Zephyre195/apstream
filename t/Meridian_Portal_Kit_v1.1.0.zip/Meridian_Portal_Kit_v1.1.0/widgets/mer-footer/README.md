# Footer (`mer-footer`)

Brand, tagline, up to 3 link columns and a legal line with the current year.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `brand_name` | string | Help Centre |  |
| `tagline` | string | – | Optional, up to 140 characters |
| `columns_json` | string | – | Array of {"heading", "links": [{"label", "url"}]}. Up to 3 columns of 8 links |
| `legal_text` | string | – | Shown after the year, e.g. Example Ltd |

## How it behaves

* As a theme footer, set `meridian.footer.<option>` system properties instead of instance options.

## Example options

Fictional values you can paste into the instance options and edit.

```json
{
  "tagline": "Answers, requests and updates in one place.",
  "legal_text": "Example Organisation",
  "columns_json": "[{\"heading\":\"Get help\",\"links\":[{\"label\":\"Report an issue\",\"url\":\"?id=sc_cat_item&sys_id=example_incident\"},{\"label\":\"Service status\",\"url\":\"?id=service_status\"},{\"label\":\"Chat\",\"url\":\"?id=chat\"}]},{\"heading\":\"Explore\",\"links\":[{\"label\":\"Request something\",\"url\":\"?id=sc_home\"},{\"label\":\"Knowledge\",\"url\":\"?id=kb_view2\"},{\"label\":\"My requests\",\"url\":\"?id=requests\"}]},{\"heading\":\"About\",\"links\":[{\"label\":\"Accessibility\",\"url\":\"?id=accessibility\"},{\"label\":\"Privacy\",\"url\":\"?id=privacy\"}]}]"
}
```
