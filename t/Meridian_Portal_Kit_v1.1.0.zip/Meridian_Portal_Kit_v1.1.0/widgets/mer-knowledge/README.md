# Popular articles (`mer-knowledge`)

The most-viewed published articles the user can read, as a numbered list.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `title` | string | Popular answers |  |
| `limit` | integer | 5 | 1 to 10 |
| `kb_id` | string | – | Optional. Leave blank for all knowledge bases the user can read |
| `article_page` | string | kb_article |  |
| `knowledge_page` | string | kb_view2 |  |

## How it behaves

* Reads `kb_knowledge` with `GlideRecordSecure` and checks each article with `$sp.canReadRecord()`.
* Limit to one knowledge base with `kb_id`.

## Example options

Fictional values you can paste into the instance options and edit.

```json
{}
```
