api.controller = function () {
  /* Meridian Portal Kit | Popular articles | v1.1.0 */
  var c = this;
  c.uid = Math.random().toString(36).slice(2, 8);
  c.views = function (n) {
    if (n >= 1000000) return (Math.round(n / 100000) / 10) + 'm views';
    if (n >= 1000) return (Math.round(n / 100) / 10) + 'k views';
    return n + (n === 1 ? ' view' : ' views');
  };
};
