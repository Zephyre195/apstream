# Action tiles (`mer-action-tiles`)

Up to 6 large shortcut tiles. With `overlap_hero` on, they sit over the bottom of the hero.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `tiles_json` | string | – | Array of {"label", "url", "description", "icon", "tone"}. Up to 6. tone: teal, coral, sun, iris |
| `heading` | string | – | Optional. Leave blank when the tiles sit under the hero |
| `overlap_hero` | boolean | true | Pulls the tiles up over the bottom of the hero search |

## How it behaves

* `tiles_json`: `label` and `url` are required; `description`, `icon` and `tone` are optional.
* Icons: help, cart, laptop, key, user, book, chat, calendar, shield, chart, folder, link, spark, phone.
* Tones: teal, coral, sun, iris (rotates when not set).

## Example options

Fictional values you can paste into the instance options and edit.

```json
{
  "tiles_json": "[{\"label\":\"Get help\",\"description\":\"Something isn't working? Tell us and we'll fix it.\",\"url\":\"?id=sc_cat_item&sys_id=example_incident\",\"icon\":\"help\",\"tone\":\"coral\"},{\"label\":\"Request something\",\"description\":\"Hardware, software, access and more.\",\"url\":\"?id=sc_home\",\"icon\":\"cart\",\"tone\":\"teal\"},{\"label\":\"Find an answer\",\"description\":\"Guides and how-tos, written for people.\",\"url\":\"?id=kb_view2\",\"icon\":\"book\",\"tone\":\"sun\"},{\"label\":\"Chat with us\",\"description\":\"Talk to the service desk, 8am to 6pm.\",\"url\":\"?id=chat\",\"icon\":\"chat\",\"tone\":\"iris\"}]"
}
```
