# Help panel (`mer-help-cta`)

A warm "Still need help?" panel with up to 3 contact actions.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `title` | string | Still need help? |  |
| `text` | string | – | Up to 200 characters |
| `actions_json` | string | – | Array of {"label", "url", "icon"}. Up to 3. The first is the main button. url can be tel: |
| `hours_text` | string | – | e.g. Monday to Friday, 8am to 6pm |

## How it behaves

* The first action is the main (dark) button. Links can be `https://`, `/`, `?id=` or `tel:`.

## Example options

Fictional values you can paste into the instance options and edit.

```json
{
  "text": "Our service desk is friendly, fast and real people.",
  "hours_text": "Monday to Friday, 8am to 6pm",
  "actions_json": "[{\"label\":\"Start a chat\",\"url\":\"?id=chat\",\"icon\":\"chat\"},{\"label\":\"Call 0123 456 7890\",\"url\":\"tel:01234567890\",\"icon\":\"phone\"},{\"label\":\"Report an issue\",\"url\":\"?id=sc_cat_item&sys_id=example_incident\",\"icon\":\"help\"}]"
}
```
