# Catalogue showcase (`mer-catalog`)

Catalogue items as visual cards, with category filter buttons.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `title` | string | Request something |  |
| `subtitle` | string | – | Optional |
| `limit` | integer | 8 | 1 to 24 |
| `show_filters` | boolean | true |  |
| `catalog_id` | string | – | Leave blank to use the portal's catalogue |
| `item_ids` | string | – | Optional comma-separated list. Items appear in this order |
| `item_page` | string | sc_cat_item |  |
| `catalog_page` | string | sc_home |  |

## How it behaves

* Shows active items from the portal's catalogue that the user can see (user criteria and Service Portal visibility are checked for each item).
* Use `item_ids` to hand-pick items in a set order. Item pictures are used when set; otherwise a tinted icon is chosen from the category.

## Example options

Fictional values you can paste into the instance options and edit.

```json
{
  "subtitle": "The things people ask for most, ready in a few clicks."
}
```
