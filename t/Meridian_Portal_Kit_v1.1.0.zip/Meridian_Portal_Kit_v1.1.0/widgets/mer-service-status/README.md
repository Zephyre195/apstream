# Service status (`mer-service-status`)

A clear status board that you update in the instance options.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `title` | string | Service status |  |
| `services_json` | string | – | Array of {"name", "status", "note"}. status: operational, maintenance, degraded, outage. Up to 12 |
| `updated_text` | string | – | e.g. Updated 09:40 |
| `details_url` | string | – | Optional. https://..., /path or ?id=page |

## How it behaves

* Statuses: operational, maintenance, degraded, outage. The banner at the top shows the worst one.
* Every status has a text label as well as a colour.

## Example options

Fictional values you can paste into the instance options and edit.

```json
{
  "updated_text": "Updated 09:40",
  "details_url": "?id=service_status",
  "services_json": "[{\"name\":\"Email and calendar\",\"status\":\"degraded\",\"note\":\"Some messages are delayed by up to 20 minutes\"},{\"name\":\"VPN\",\"status\":\"operational\"},{\"name\":\"Wi-Fi in offices\",\"status\":\"operational\"},{\"name\":\"Expenses\",\"status\":\"maintenance\",\"note\":\"Saturday 07:00 to 09:00\"}]"
}
```
