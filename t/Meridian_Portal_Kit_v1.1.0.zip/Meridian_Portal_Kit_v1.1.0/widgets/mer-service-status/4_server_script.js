(function () {
  /* Meridian Portal Kit | Service status | v1.1.0
     A simple status board maintained in instance options. No table queries, no writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  var notes = [];
  var RANK = { operational: 0, maintenance: 1, degraded: 2, outage: 3 };
  var LABEL = { operational: 'Working normally', maintenance: 'Planned maintenance', degraded: 'Some problems', outage: 'Not working' };
  data.title = cleanText(options.title, 60) || 'Service status';
  data.updated = cleanText(options.updated_text, 60);
  data.details_url = safeUrl(options.details_url);
  data.services = [];
  var worst = 0;
  var raw = readList(options.services_json, 'services_json', notes);
  for (var i = 0; i < raw.length; i++) {
    var s = raw[i] || {};
    if (data.services.length >= 12) { notes.push('Only the first 12 services are shown.'); break; }
    var name = cleanText(s.name, 50);
    if (!name) { notes.push('Service ' + (i + 1) + ' needs a name.'); continue; }
    var st = RANK.hasOwnProperty(s.status) ? s.status : 'operational';
    if (s.status && !RANK.hasOwnProperty(s.status)) notes.push('"' + name + '" has an unknown status; use operational, maintenance, degraded or outage.');
    if (RANK[st] > worst) worst = RANK[st];
    data.services.push({ name: name, status: st, label: LABEL[st], note: cleanText(s.note, 100) });
  }
  data.overall = ['operational', 'maintenance', 'degraded', 'outage'][worst];
  data.overall_text = worst === 0 ? 'All services are working normally' : (worst === 1 ? 'Planned maintenance is scheduled' : 'Some services are affected');
  data.config_error = notes.join(' ');
})();
