# Hero search (`mer-hero`)

The big welcome area: greeting, title, search and popular searches.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `title` | string | How can we help today? | Up to 90 characters |
| `subtitle` | string | – | Optional, up to 200 characters |
| `show_greeting` | boolean | true |  |
| `placeholder` | string | Search for help, services and articles |  |
| `suggestions_json` | string | – | Array of short phrases, up to 6, e.g. ["Reset password", "VPN"] |
| `search_page` | string | search | Opens ?id=<page>&q=<text> |
| `notice_text` | string | – | Optional one-line notice under the search |
| `notice_url` | string | – | https://..., /path or ?id=page |

## How it behaves

* Search opens `?id=<search_page>&spa=1&q=<text>` in the portal. An empty search shows a short message instead.
* Popular searches (`suggestions_json`) are buttons that run that search. Up to 6.
* The greeting uses the viewer's local time and first name; turn it off with `show_greeting`.

## Example options

Fictional values you can paste into the instance options and edit.

```json
{
  "subtitle": "Search once to find answers, request what you need and track it to done.",
  "suggestions_json": "[\"Reset password\",\"VPN\",\"New laptop\",\"Book a desk\",\"Expenses\"]",
  "notice_text": "Email is running slowly for some people. We're on it.",
  "notice_url": "?id=service_status"
}
```
