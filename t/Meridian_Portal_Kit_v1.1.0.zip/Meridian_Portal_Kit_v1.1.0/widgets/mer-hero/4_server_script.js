(function () {
  /* Meridian Portal Kit | Hero search | v1.1.0
     Greeting, search box and popular searches. Reads instance options and the current user's first name.
     No table queries, no writes. ES5 syntax. */
  function cleanText(v, max) {
    if (v === undefined || v === null) return '';
    var s = String(v).replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return s.length > max ? s.substring(0, max - 1) + '…' : s;
  }
  function safeUrl(v) {
    var s = cleanText(v, 500);
    if (!s) return '';
    if (/^https?:\/\/[^\s]+$/i.test(s)) return s;
    if (s.charAt(0) === '/' && s.charAt(1) !== '/' && s.charAt(1) !== '\\') return s;
    if (s.charAt(0) === '?') return s;
    return '';
  }
  function readList(raw, name, notes) {
    if (raw === undefined || raw === null || raw === '') return [];
    var v = raw;
    if (typeof raw === 'string') {
      try { v = JSON.parse(raw); } catch (e) { notes.push('The ' + name + ' option is not valid JSON. Check quotes and commas.'); return []; }
    }
    if (Object.prototype.toString.call(v) !== '[object Array]') { notes.push('The ' + name + ' option must be a JSON array.'); return []; }
    return v;
  }
  function pageId(v, fallback) { var s = cleanText(v, 80); return /^[A-Za-z0-9_\-]+$/.test(s) ? s : fallback; }
  function intOpt(v, def, min, max) { var n = parseInt(v, 10); if (isNaN(n)) return def; return Math.max(min, Math.min(max, n)); }
  function boolOpt(v, def) { if (v === true || v === 'true') return true; if (v === false || v === 'false') return false; return def; }
  data.is_admin = gs.hasRole('sp_admin') || gs.hasRole('admin');
  var notes = [];
  data.title = cleanText(options.title, 90) || 'How can we help today?';
  data.subtitle = cleanText(options.subtitle, 200);
  data.placeholder = cleanText(options.placeholder, 80) || 'Search for help, services and articles';
  data.search_page = pageId(options.search_page, 'search');
  data.greet = boolOpt(options.show_greeting, true);
  data.first_name = gs.isLoggedIn() ? cleanText(gs.getUser().getFirstName(), 40) : '';
  data.suggestions = [];
  var raw = readList(options.suggestions_json, 'suggestions_json', notes);
  for (var i = 0; i < raw.length && data.suggestions.length < 6; i++) {
    var s = cleanText(raw[i], 40);
    if (s) data.suggestions.push(s);
  }
  data.notice = cleanText(options.notice_text, 140);
  data.notice_url = safeUrl(options.notice_url);
  if (options.notice_url && !data.notice_url) notes.push('notice_url must start with https://, http://, / or ?id=');
  data.config_error = notes.join(' ');
})();
