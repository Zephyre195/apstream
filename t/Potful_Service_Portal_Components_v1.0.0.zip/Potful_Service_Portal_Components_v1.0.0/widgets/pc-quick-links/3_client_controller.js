api.controller = function () {
  /* Potful Service Portal Components | Quick-link cards | v1.0.0
     Icons are original 24x24 stroke paths (see LICENSE). */
  var c = this;
  var ICON_PATHS = {
    link: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1.2 1.2M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1.2-1.2',
    laptop: 'M5 6h14v9H5zM3 18h18',
    key: 'M14.5 4a5.5 5.5 0 1 1-4.9 8L3.5 18v2.5H6l.5-1.5H8v-1.5h1.5l1.4-1.4A5.5 5.5 0 0 1 14.5 4zM16 8.2h.1',
    user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4.5 20a7.5 7.5 0 0 1 15 0',
    book: 'M5 4.5h6a2 2 0 0 1 2 2V20a2 2 0 0 0-2-2H5zM19 4.5h-6a2 2 0 0 0-2 2V20a2 2 0 0 1 2-2h6z',
    help: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9.6 9.5a2.5 2.5 0 1 1 3.4 2.3c-.6.3-1 .8-1 1.5v.4M12 17h.1',
    cart: 'M3 4h2.5l2.2 10.5h10l2-7.5H6.5M9.5 19.5h.1M17 19.5h.1',
    calendar: 'M4.5 6h15v14h-15zM4.5 10.5h15M8.5 3.5V8M15.5 3.5V8',
    chat: 'M4.5 5.5h15v10h-8l-4.5 4v-4h-2.5z',
    shield: 'M12 3l7.5 3v5.5c0 4.5-3.2 8-7.5 9.5-4.3-1.5-7.5-5-7.5-9.5V6zM9 12l2 2 4-4.5',
    chart: 'M5 20V11M10 20V5M15 20v-7M20 20V8M3.5 20h17',
    folder: 'M3.5 6.5h6l2 2h9v10h-17z'
  };
  c.iconPath = function (name) { return ICON_PATHS[name] || ICON_PATHS.link; };
  c.uid = 'pc-ql-' + Math.random().toString(36).slice(2, 9);
};
