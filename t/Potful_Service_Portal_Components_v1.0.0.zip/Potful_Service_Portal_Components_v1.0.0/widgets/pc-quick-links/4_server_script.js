(function () {
  /* Potful Service Portal Components | Quick-link cards | v1.0.0
     Presentation only: reads instance options (or options passed by an embedding widget).
     No table queries, no writes. ES5 syntax. */
  var MAX_LINKS = 24;
  var ICONS = ['link', 'laptop', 'key', 'user', 'book', 'help', 'cart', 'calendar', 'chat', 'shield', 'chart', 'folder'];

  data.title = cleanText(options.title, 120);
  data.intro = cleanText(options.intro, 240);
  var cols = parseInt(options.columns, 10);
  data.columns = (cols === 2 || cols === 3 || cols === 4) ? cols : 3;
  data.card_style = options.card_style === 'filled' ? 'filled' : 'outline';
  data.links = [];
  data.config_error = '';
  data.is_admin = canSeeConfigErrors();

  var parsed = [];
  var raw = options.links_json;
  if (raw !== undefined && raw !== null && raw !== '') {
    if (typeof raw === 'string') {
      try { parsed = JSON.parse(raw); } catch (e) { data.config_error = 'The links_json option is not valid JSON. Check quotes and commas.'; parsed = []; }
    } else {
      parsed = raw;
    }
  }
  if (!data.config_error && Object.prototype.toString.call(parsed) !== '[object Array]') {
    data.config_error = 'The links_json option must be a JSON array of links.';
    parsed = [];
  }

  var skipped = [];
  for (var i = 0; i < parsed.length; i++) {
    var l = parsed[i];
    if (!l || typeof l !== 'object') { skipped.push('item ' + (i + 1) + ' is not an object'); continue; }
    var label = cleanText(l.label, 60);
    var url = safeUrl(l.url);
    if (!label) { skipped.push('item ' + (i + 1) + ' has no label'); continue; }
    if (!url) { skipped.push('"' + label + '" has a missing or unsupported URL'); continue; }
    if (data.links.length >= MAX_LINKS) { skipped.push('"' + label + '" is over the limit of ' + MAX_LINKS); continue; }
    var icon = String(l.icon || 'link').toLowerCase();
    var external = /^https?:/i.test(url);
    data.links.push({
      label: label,
      description: cleanText(l.description, 140),
      url: url,
      icon: ICONS.indexOf(icon) >= 0 ? icon : 'link',
      badge: cleanText(l.badge, 20),
      new_tab: external && (l.new_tab === true || String(l.new_tab).toLowerCase() === 'true')
    });
  }
  if (skipped.length && !data.config_error) {
    data.config_error = 'Some links were skipped: ' + skipped.slice(0, 5).join('; ') + (skipped.length > 5 ? '; and ' + (skipped.length - 5) + ' more' : '') + '.';
  }

  function safeUrl(value) {
    var url = cleanText(value, 500);
    if (!url) return '';
    if (/^https?:\/\/[^\s]+$/i.test(url)) return url;
    if (/^\/(?!\/)[^\s]*$/.test(url)) return url;
    if (/^\?[^\s]*$/.test(url)) return url;
    return '';
  }
  function cleanText(value, max) {
    if (value === undefined || value === null) return '';
    var text = String(value).replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return text.length > max ? text.substring(0, max - 1) + '…' : text;
  }
  function canSeeConfigErrors() {
    try { return gs.hasRole('sp_admin') || gs.hasRole('admin'); } catch (e) { return false; }
  }
})();
