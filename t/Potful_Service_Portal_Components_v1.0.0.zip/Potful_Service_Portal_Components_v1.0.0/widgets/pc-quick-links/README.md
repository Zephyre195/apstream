# Quick-link cards (`pc-quick-links`)

A responsive grid of link cards for the things people look for most: get help, request something, check status, read policies.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `title` | string | – | Optional heading |
| `intro` | string | – | Optional, up to 240 characters |
| `links_json` | string | – | Array of {"label", "url", "description", "icon", "badge", "new_tab"}. Up to 24 links |
| `columns` | choice (2, 3, 4) | 3 | Cards reflow to 2 and 1 columns on smaller screens |
| `card_style` | choice (outline, filled) | outline |  |

## How it behaves

* `links_json` is a JSON array. Each link: `label` (required, up to 60 characters), `url` (required), optional `description` (up to 140), `icon`, `badge` (up to 20) and `new_tab` (http/https links only).
* Built-in icons: `help`, `cart`, `laptop`, `key`, `user`, `book`, `chat`, `calendar`, `shield`, `chart`, `folder`, `link` (default).
* Links with an unsafe or missing URL are skipped and listed in the admin-only set-up note.
* Cards are real links with visible focus rings. Columns reflow to 2 and then 1 on narrow screens. The breakpoints follow the screen width, so in a narrow page column (for example half width) choose 2 columns.

## Examples

Copy any of these from `example_instance_options.json` into the instance options. All names and data are fictional.

### Service portal home (3 columns)

```json
{
  "title": "Popular services",
  "intro": "Start here for the things people ask for most.",
  "columns": "3",
  "links_json": "[{\"label\":\"Request a laptop\",\"url\":\"?id=sc_cat_item&sys_id=example1\",\"description\":\"New or replacement equipment\",\"icon\":\"laptop\"},{\"label\":\"Reset a password\",\"url\":\"?id=pwd_reset\",\"description\":\"Unlock your account in minutes\",\"icon\":\"key\",\"badge\":\"Fast\"},{\"label\":\"Request access\",\"url\":\"?id=sc_cat_item&sys_id=example2\",\"description\":\"Apps, shared drives and groups\",\"icon\":\"shield\"},{\"label\":\"Knowledge base\",\"url\":\"?id=kb_home\",\"description\":\"Guides and how-tos\",\"icon\":\"book\"},{\"label\":\"Get help\",\"url\":\"?id=sc_cat_item&sys_id=example3\",\"description\":\"Report something that isn't working\",\"icon\":\"help\"},{\"label\":\"My requests\",\"url\":\"?id=requests\",\"description\":\"Track what you've asked for\",\"icon\":\"folder\"}]"
}
```

### Filled style (4 columns)

```json
{
  "columns": "4",
  "card_style": "filled",
  "links_json": "[{\"label\":\"Book a desk\",\"url\":\"/desks\",\"icon\":\"calendar\"},{\"label\":\"Chat to IT\",\"url\":\"?id=chat\",\"icon\":\"chat\"},{\"label\":\"Buy software\",\"url\":\"?id=sc_category\",\"icon\":\"cart\"},{\"label\":\"Service status\",\"url\":\"https://status.example.com\",\"icon\":\"chart\",\"new_tab\":true}]"
}
```
