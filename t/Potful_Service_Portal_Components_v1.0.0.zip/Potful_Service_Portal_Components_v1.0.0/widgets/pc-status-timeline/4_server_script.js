(function () {
  /* Potful Service Portal Components | Status timeline | v1.0.0
     Presentation only: reads instance options (or options passed by an embedding widget).
     No table queries, no writes. ES5 syntax for the global scope. */
  var MAX_STEPS = 12;
  var STATE_LABELS = {
    complete: 'Complete',
    current: 'In progress',
    upcoming: 'Not started',
    blocked: 'Blocked',
    skipped: 'Skipped'
  };

  data.title = cleanText(options.title, 120);
  data.orientation = options.orientation === 'horizontal' ? 'horizontal' : 'vertical';
  data.compact = toBool(options.compact);
  data.empty_text = cleanText(options.empty_text, 200) || 'There is nothing to show yet.';
  data.steps = [];
  data.config_error = '';
  data.is_admin = canSeeConfigErrors();

  var parsed = [];
  var raw = options.steps_json;
  if (raw !== undefined && raw !== null && raw !== '') {
    if (typeof raw === 'string') {
      try {
        parsed = JSON.parse(raw);
      } catch (e) {
        data.config_error = 'The steps_json option is not valid JSON. Check quotes and commas.';
        parsed = [];
      }
    } else {
      parsed = raw;
    }
  }
  if (!data.config_error && Object.prototype.toString.call(parsed) !== '[object Array]') {
    data.config_error = 'The steps_json option must be a JSON array of steps.';
    parsed = [];
  }

  var skipped = 0;
  for (var i = 0; i < parsed.length; i++) {
    var s = parsed[i];
    if (!s || typeof s !== 'object') { skipped++; continue; }
    var label = cleanText(s.label, 80);
    if (!label) { skipped++; continue; }
    if (data.steps.length >= MAX_STEPS) { skipped++; continue; }
    var state = String(s.state || 'upcoming').toLowerCase();
    if (!STATE_LABELS.hasOwnProperty(state)) state = 'upcoming';
    data.steps.push({
      label: label,
      detail: cleanText(s.detail, 240),
      date: cleanText(s.date, 40),
      state: state,
      state_label: cleanText(s.state_label, 40) || STATE_LABELS[state]
    });
  }
  if (skipped && !data.config_error) {
    data.config_error = skipped + ' step(s) were skipped: each step needs a label, and at most ' + MAX_STEPS + ' steps are shown.';
  }

  var done = 0, currentIndex = -1;
  for (var j = 0; j < data.steps.length; j++) {
    if (data.steps[j].state === 'complete' || data.steps[j].state === 'skipped') done++;
    if (data.steps[j].state === 'current' && currentIndex < 0) currentIndex = j;
  }
  data.summary = {
    total: data.steps.length,
    done: done,
    current_index: currentIndex,
    current_label: currentIndex >= 0 ? data.steps[currentIndex].label : ''
  };

  function cleanText(value, max) {
    if (value === undefined || value === null) return '';
    var text = String(value).replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return text.length > max ? text.substring(0, max - 1) + '…' : text;
  }
  function toBool(value) {
    return value === true || String(value).toLowerCase() === 'true';
  }
  function canSeeConfigErrors() {
    try { return gs.hasRole('sp_admin') || gs.hasRole('admin'); } catch (e) { return false; }
  }
})();
