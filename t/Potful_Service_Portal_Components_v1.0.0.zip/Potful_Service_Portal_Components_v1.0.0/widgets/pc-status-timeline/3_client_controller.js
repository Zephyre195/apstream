api.controller = function () {
  /* Potful Service Portal Components | Status timeline | v1.0.0 */
  var c = this;
  c.uid = 'pc-tl-' + Math.random().toString(36).slice(2, 9);

  c.summaryText = function () {
    var s = c.data.summary || {};
    if (!s.total) return '';
    var text = s.done + ' of ' + s.total + ' steps complete.';
    if (s.current_index >= 0) text += ' Current step: ' + s.current_label + '.';
    return text;
  };
};
