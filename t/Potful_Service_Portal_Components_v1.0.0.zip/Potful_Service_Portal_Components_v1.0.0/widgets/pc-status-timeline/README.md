# Status timeline (`pc-status-timeline`)

Shows where something is in a process: a request, an onboarding journey, an incident or a change.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `title` | string | – | Optional heading, up to 120 characters |
| `steps_json` | string | – | Array of {"label", "state", "date", "detail"}. state: complete, current, upcoming, blocked or skipped. Up to 12 steps. |
| `orientation` | choice (vertical, horizontal) | vertical | Horizontal falls back to vertical below 720px wide |
| `compact` | boolean | false |  |
| `empty_text` | string | – | Default: There is nothing to show yet. |

## How it behaves

* `steps_json` is a JSON array (a JSON string in the options form; an array is also accepted when embedding). Each step: `label` (required), `state`, optional `date` and `detail`.
* States: `complete`, `current`, `upcoming`, `blocked`, `skipped`. Unknown states are treated as `upcoming`. Up to 12 steps; steps without a label, or beyond 12, are skipped and counted in the admin set-up note.
* The current step gets `aria-current="step"`, and a hidden summary such as "Step 3 of 5: Device prepared" is read by screen readers.
* Horizontal layout is used on screens 720px and wider; it switches to vertical below that.

## Examples

Copy any of these from `example_instance_options.json` into the instance options. All names and data are fictional.

### Request progress (vertical)

```json
{
  "title": "Your laptop request",
  "steps_json": "[{\"label\":\"Request submitted\",\"state\":\"complete\",\"date\":\"3 Nov\",\"detail\":\"REQ0010421 created by Sam Rivers (fictional)\"},{\"label\":\"Manager approval\",\"state\":\"complete\",\"date\":\"4 Nov\",\"detail\":\"Approved by Priya Shah (fictional)\"},{\"label\":\"Device prepared\",\"state\":\"current\",\"detail\":\"IT are setting up your laptop and installing standard software.\"},{\"label\":\"Ready to collect\",\"state\":\"upcoming\"},{\"label\":\"Closed\",\"state\":\"upcoming\"}]"
}
```

### Onboarding (horizontal, compact)

```json
{
  "title": "New starter onboarding",
  "orientation": "horizontal",
  "compact": "true",
  "steps_json": "[{\"label\":\"Accounts\",\"state\":\"complete\",\"date\":\"Mon\"},{\"label\":\"Equipment\",\"state\":\"complete\",\"date\":\"Tue\"},{\"label\":\"Access\",\"state\":\"blocked\",\"state_label\":\"Waiting on owner\"},{\"label\":\"Training\",\"state\":\"upcoming\"},{\"label\":\"Welcome call\",\"state\":\"upcoming\"}]"
}
```
