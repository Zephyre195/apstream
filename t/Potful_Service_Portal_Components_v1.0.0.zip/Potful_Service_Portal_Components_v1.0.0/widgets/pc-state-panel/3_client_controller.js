api.controller = function ($scope) {
  /* Potful Service Portal Components | Loading, empty and error states | v1.0.0
     Retry either emits an event for the parent widget to handle (default)
     or re-runs this widget's server script (retry_mode = refresh). */
  var c = this;
  var widths = [92, 76, 84, 64, 88, 70, 80, 58];
  c.rows = widths.slice(0, c.data.skeleton_rows || 3);
  c.retrying = false;

  c.retry = function () {
    if (c.retrying) return;
    if (c.data.retry_mode === 'refresh' && c.server && typeof c.server.refresh === 'function') {
      c.retrying = true;
      var done = function () { c.retrying = false; };
      var p = c.server.refresh();
      if (p && typeof p.then === 'function') p.then(done, done); else done();
      return;
    }
    $scope.$emit(c.data.retry_event, { widget: 'pc-state-panel', state: c.data.state });
  };
};
