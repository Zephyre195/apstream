(function () {
  /* Potful Service Portal Components | Loading, empty and error states | v1.0.0
     Presentation only. Usually embedded by another widget with $sp.getWidget('pc-state-panel', {...}).
     No table queries, no writes. ES5 syntax. */
  var STATES = ['loading', 'empty', 'error'];
  var DEFAULTS = {
    loading: { title: 'Loading', message: '' },
    empty: { title: 'Nothing here yet', message: 'When there is something to show, it will appear here.' },
    error: { title: 'Something went wrong', message: 'This section could not be loaded. Please try again.' }
  };

  var state = String(options.state || 'loading').toLowerCase();
  data.state = STATES.indexOf(state) >= 0 ? state : 'loading';
  data.title = cleanText(options.title, 80) || DEFAULTS[data.state].title;
  data.message = cleanText(options.message, 240) || DEFAULTS[data.state].message;
  var rows = parseInt(options.skeleton_rows, 10);
  data.skeleton_rows = isNaN(rows) ? 3 : Math.max(1, Math.min(8, rows));
  data.action_label = cleanText(options.action_label, 40);
  data.action_url = safeUrl(options.action_url);
  data.retry_label = cleanText(options.retry_label, 40) || 'Try again';
  data.show_retry = data.state === 'error' && options.show_retry !== false && String(options.show_retry).toLowerCase() !== 'false';
  data.retry_event = cleanText(options.retry_event, 60).replace(/[^A-Za-z0-9_.:-]/g, '-') || 'pc-state:retry';
  data.retry_mode = options.retry_mode === 'refresh' ? 'refresh' : 'event';
  data.compact = options.compact === true || String(options.compact).toLowerCase() === 'true';

  function safeUrl(value) {
    var url = cleanText(value, 500);
    if (!url) return '';
    if (/^https?:\/\/[^\s]+$/i.test(url)) return url;
    if (/^\/(?!\/)[^\s]*$/.test(url)) return url;
    if (/^\?[^\s]*$/.test(url)) return url;
    return '';
  }
  function cleanText(value, max) {
    if (value === undefined || value === null) return '';
    var text = String(value).replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return text.length > max ? text.substring(0, max - 1) + '…' : text;
  }
})();
