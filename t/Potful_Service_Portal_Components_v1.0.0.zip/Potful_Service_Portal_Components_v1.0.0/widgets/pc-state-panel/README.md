# Loading, empty and error states (`pc-state-panel`)

Consistent placeholders for data that is loading, a list with no results, and something that failed.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `state` | choice (loading, empty, error) | loading | Usually set by the embedding widget |
| `title` | string | – | Defaults: Loading / Nothing here yet / Something went wrong |
| `message` | string | – | Optional, up to 240 characters |
| `skeleton_rows` | integer | 3 |  |
| `action_label` | string | – | Empty and error states |
| `action_url` | string | – | https://..., /path or ?id=page_id |
| `show_retry` | boolean | true |  |
| `retry_label` | string | – | Default: Try again |
| `retry_mode` | choice (event, refresh) | event | event: tell the parent widget. refresh: re-run this widget's server script |
| `retry_event` | string | – | Default: pc-state:retry |
| `compact` | boolean | false |  |

## How it behaves

* Usually embedded by another widget, which sets `state` (see EMBEDDING.md). It can also be placed on a page to preview or document your patterns.
* Loading shows `skeleton_rows` shimmering placeholder rows (1 to 8) with `aria-busy`; the shimmer stops when the viewer has turned on reduced motion.
* Retry: `event` mode emits `retry_event` (default `pc-state:retry`) upwards with `$scope.$emit` so the parent widget can reload. `refresh` mode re-runs this widget's server script.
* The action link (`action_label` + `action_url`) appears in the empty and error states.

## Examples

Copy any of these from `example_instance_options.json` into the instance options. All names and data are fictional.

### Loading

```json
{
  "state": "loading",
  "title": "Loading your requests",
  "skeleton_rows": "4"
}
```

### Empty

```json
{
  "state": "empty",
  "title": "No open requests",
  "message": "Anything you ask for will appear here so you can track it.",
  "action_label": "Browse the catalogue",
  "action_url": "?id=sc_home"
}
```

### Error with retry

```json
{
  "state": "error",
  "message": "We couldn't load your requests just now. Your data is safe.",
  "retry_label": "Try again"
}
```
