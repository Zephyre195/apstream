# Announcement banner (`pc-announcement-banner`)

Shows one short message across the top of a page: planned maintenance, an outage, a policy change or good news.

## Options

| Option | Type | Default | Notes |
|---|---|---|---|
| `message` | string | – | Required. Plain text, up to 300 characters |
| `title` | string | – | Optional, shown in bold before the message |
| `variant` | choice (info, success, warning, critical) | info |  |
| `link_label` | string | – | Default: Find out more |
| `link_url` | string | – | https://..., /path or ?id=page_id. Other schemes are ignored |
| `link_new_tab` | boolean | false | Only applies to https:// and http:// links |
| `dismissible` | boolean | false | Remembered in the viewer's browser |
| `dismiss_key` | string | – | Any short name, e.g. outage-2026-11. Change it to show a new announcement to everyone |
| `start_date` | string | – | Optional. Viewer's local date |
| `end_date` | string | – | Optional. Inclusive |

## How it behaves

* Four variants: info, success, warning, critical. Each has an icon and a text label (read by screen readers in the region name), so colour is never the only signal.
* Dates use `YYYY-MM-DD` and the viewer's local date. `end_date` is inclusive. Outside the window the banner renders nothing.
* Dismiss: needs `dismissible` **and** `dismiss_key`. The choice is stored in the viewer's browser. Use a new key for a new announcement.
* If `message` is blank the banner renders nothing for users and an admin-only set-up note for admins.

## Examples

Copy any of these from `example_instance_options.json` into the instance options. All names and data are fictional.

### Information

```json
{
  "title": "Planned maintenance",
  "message": "The portal will be read-only on Saturday from 07:00 to 09:00 while we upgrade it.",
  "variant": "info",
  "link_label": "See what's changing",
  "link_url": "?id=kb_article&sys_id=example",
  "dismissible": "true",
  "dismiss_key": "maint-2026-11"
}
```

### Good news

```json
{
  "message": "Password resets now take under a minute from the portal.",
  "variant": "success",
  "title": "New"
}
```

### Warning

```json
{
  "title": "Email delays",
  "message": "Some notification emails are arriving late. Requests are still being processed.",
  "variant": "warning"
}
```

### Important

```json
{
  "title": "Outage",
  "message": "Remote access is unavailable. We are working on a fix and will update this page every 30 minutes.",
  "variant": "critical",
  "link_label": "Status page",
  "link_url": "https://status.example.com",
  "link_new_tab": "true"
}
```
