api.controller = function () {
  /* Potful Service Portal Components | Announcement banner | v1.0.0
     Date window uses the viewer's local date. Dismissals are remembered in this browser only. */
  var c = this;
  var STORE_PREFIX = 'pc-banner-dismissed:';

  function today() {
    var d = new Date();
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function storage() {
    try { var s = window.localStorage; s.getItem('pc-test'); return s; } catch (e) { return null; }
  }
  function wasDismissed() {
    if (!c.data.dismissible || !c.data.dismiss_key) return false;
    var s = storage();
    return !!(s && s.getItem(STORE_PREFIX + c.data.dismiss_key) === '1');
  }
  function inWindow() {
    var t = today();
    if (c.data.start_date && t < c.data.start_date) return false;
    if (c.data.end_date && t > c.data.end_date) return false;
    return true;
  }

  c.visible = !!c.data.message && inWindow() && !wasDismissed();

  c.dismiss = function () {
    c.visible = false;
    var s = storage();
    if (s && c.data.dismiss_key) {
      try { s.setItem(STORE_PREFIX + c.data.dismiss_key, '1'); } catch (e) { /* storage full or blocked: hide for this page view only */ }
    }
  };
};
