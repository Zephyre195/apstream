(function () {
  /* Potful Service Portal Components | Announcement banner | v1.0.0
     Presentation only: reads instance options. No table queries, no writes. ES5 syntax. */
  var VARIANTS = { info: 'Information', success: 'Good news', warning: 'Warning', critical: 'Important' };

  data.title = cleanText(options.title, 80);
  data.message = cleanText(options.message, 300);
  data.variant = VARIANTS.hasOwnProperty(String(options.variant)) ? String(options.variant) : 'info';
  data.variant_label = VARIANTS[data.variant];
  data.link_label = cleanText(options.link_label, 40) || 'Find out more';
  data.link_url = safeUrl(options.link_url);
  data.link_new_tab = toBool(options.link_new_tab) && /^https?:/i.test(data.link_url);
  data.dismissible = toBool(options.dismissible);
  data.dismiss_key = cleanText(options.dismiss_key, 60).replace(/[^A-Za-z0-9_.-]/g, '-');
  data.start_date = isoDate(options.start_date);
  data.end_date = isoDate(options.end_date);
  data.config_error = '';
  data.is_admin = canSeeConfigErrors();

  var problems = [];
  if (!data.message) problems.push('add a message');
  if (options.link_url && !data.link_url) problems.push('the link must start with https://, http://, / or ?id=');
  if (options.start_date && !data.start_date) problems.push('start_date must be YYYY-MM-DD');
  if (options.end_date && !data.end_date) problems.push('end_date must be YYYY-MM-DD');
  if (data.start_date && data.end_date && data.start_date > data.end_date) problems.push('start_date is after end_date');
  if (data.dismissible && !data.dismiss_key) problems.push('set dismiss_key so a dismissal can be remembered (change it to show a new announcement)');
  if (problems.length) data.config_error = 'To finish setting up this banner: ' + problems.join('; ') + '.';

  function safeUrl(value) {
    var url = cleanText(value, 500);
    if (!url) return '';
    if (/^https?:\/\/[^\s]+$/i.test(url)) return url;
    if (/^\/(?!\/)[^\s]*$/.test(url)) return url;
    if (/^\?[^\s]*$/.test(url)) return url;
    return '';
  }
  function isoDate(value) {
    var text = cleanText(value, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return '';
    var parts = text.split('-');
    var m = parseInt(parts[1], 10), d = parseInt(parts[2], 10);
    return (m >= 1 && m <= 12 && d >= 1 && d <= 31) ? text : '';
  }
  function cleanText(value, max) {
    if (value === undefined || value === null) return '';
    var text = String(value).replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
    return text.length > max ? text.substring(0, max - 1) + '…' : text;
  }
  function toBool(value) {
    return value === true || String(value).toLowerCase() === 'true';
  }
  function canSeeConfigErrors() {
    try { return gs.hasRole('sp_admin') || gs.hasRole('admin'); } catch (e) { return false; }
  }
})();
