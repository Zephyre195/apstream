# Use a widget inside your own widget

Every widget accepts the same options from code as it does from the instance options form, so you can drive them from your own widget's server script. **This pattern is standard Service Portal widget embedding, but the examples below have not been run on a live instance yet** (see COMPATIBILITY_AND_LIMITATIONS.md).

## Status timeline from your data

Server script of **your** widget:

```javascript
(function () {
  // Build steps from whatever your widget already knows. Keep it to 12 steps or fewer.
  var steps = [
    { label: 'Submitted', state: 'complete', date: '3 Nov' },
    { label: 'Approval', state: 'current', detail: 'Waiting for your manager' },
    { label: 'Fulfilment', state: 'upcoming' }
  ];
  data.timeline = $sp.getWidget('pc-status-timeline', {
    title: 'Progress',
    steps_json: steps          // an array is fine; a JSON string works too
  });
})();
```

HTML template of **your** widget:

```html
<sp-widget widget="c.data.timeline"></sp-widget>
```

## Loading, empty and error states

Show the state panel while your widget fetches data, and listen for the retry event:

```javascript
// Server script (your widget)
(function () {
  if (input && input.action === 'load') {
    // ... load your rows into data.rows ...
  }
  data.loading = $sp.getWidget('pc-state-panel', { state: 'loading', title: 'Loading your requests' });
  data.empty   = $sp.getWidget('pc-state-panel', { state: 'empty', title: 'No open requests', action_label: 'Browse the catalogue', action_url: '?id=sc_home' });
  data.failed  = $sp.getWidget('pc-state-panel', { state: 'error', retry_event: 'my-requests:retry' });
})();
```

```javascript
// Client script (your widget)
api.controller = function ($scope) {
  var c = this;
  $scope.$on('my-requests:retry', function () {
    c.server.get({ action: 'load' }).then(function (r) { c.data.rows = r.data.rows; });
  });
};
```

```html
<!-- HTML template (your widget) -->
<sp-widget widget="c.data.loading" ng-if="c.isLoading"></sp-widget>
<sp-widget widget="c.data.failed" ng-if="c.hasError"></sp-widget>
<sp-widget widget="c.data.empty" ng-if="!c.isLoading && !c.hasError && !c.data.rows.length"></sp-widget>
```

The retry button emits the event upwards with `$scope.$emit`, so the nearest parent widget that listens for it can reload. Set `retry_mode` to `refresh` instead if you want the state panel to re-run its own server script.

## Quick links and banners

Pass `links_json` as an array of objects, or the banner options as plain values:

```javascript
data.links = $sp.getWidget('pc-quick-links', { columns: '3', links_json: [ { label: 'Get help', url: '?id=sc_home', icon: 'help' } ] });
data.notice = $sp.getWidget('pc-announcement-banner', { message: 'Read-only on Saturday 07:00 to 09:00', variant: 'warning' });
```
