# Changelog

## 1.0.0 – 10 November 2026

First release.

* Announcement banner, quick-link cards, status timeline, and loading/empty/error states.
* Offline demo and playground.
* Install, embedding, compatibility, licence and support documents.

TEST_RESULTS: see COMPATIBILITY_AND_LIMITATIONS.md. Automated accessibility scan (axe-core, WCAG 2.1 A and AA rules) of the demo page: 0 violations. Automated scans find only some accessibility issues; manual checks with a screen reader have not been done.
