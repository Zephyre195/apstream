# Support

**Included:** help with defects in these files and clarification of the documentation. Message Potful through Etsy with the widget ID, your ServiceNow release, what you expected and what happened (a screenshot helps). I usually reply within two working days.

**Not included:** customising the widgets for your portal, building new features, implementation work on your instance, or troubleshooting other customisations or themes.

**Updates:** fixes are released as new versions (see CHANGELOG.md) and added to your Etsy download. No promise of compatibility with every future ServiceNow release.
