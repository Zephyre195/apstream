# Compatibility and limitations

## Built for

* **ServiceNow Service Portal** widgets (AngularJS-based). The widgets use only the standard widget fields: HTML template, CSS - SCSS, client controller, server script and option schema (option types `string`, `boolean`, `integer` and `choice`).
* Server scripts are written in ES5 syntax so they run in the global scope as well as in scoped applications.
* The CSS is plain CSS (which is also valid SCSS). It uses CSS custom properties (`var(--pc-...)`), flexbox and grid.

## What has been tested (v1.0.0, 10 November 2026)

| Check | Tool | Result |
|---|---|---|
| Server scripts: normal, blank, malformed, boundary and unsafe-URL inputs (22 tests) | Node.js sandbox with mocked `gs` | Passed |
| Rendering of every example, option changes, dismiss, retry event | Offline demo: AngularJS 1.8.3 + Bootstrap 3.4.1, Chromium via Playwright | Passed |
| Layout at 390px and 1280px wide | Same | Passed |
| Automated accessibility scan of the demo page | axe-core 4.14, WCAG 2.1 A and AA rules | 0 violations |
| Reduced-motion setting turns off the loading shimmer | Same | Passed |

## Not tested yet

* **On a live ServiceNow instance, on any release.** The offline demo imitates Service Portal but is not Service Portal. Install in a sub-production instance first and test with your theme.
* Employee Center and other portals built on Service Portal: likely to work like any other Service Portal widget, but not tested.
* Browsers other than Chromium; screen readers other than automated checks.

## Not supported

* **UI Builder, Next Experience workspaces and other non-Service Portal interfaces.** These widgets are AngularJS Service Portal widgets.
* Rich text or HTML in messages. Everything is shown as plain text on purpose.

## Limitations by design

* No table queries, record writes or outbound calls. Data comes from instance options or an embedding widget.
* Status timeline: up to 12 steps. Quick links: up to 24 links and 12 built-in icons. Text fields are trimmed to the lengths shown in each widget's README.
* Links must start with `https://`, `http://`, `/` (not `//`) or `?`. Anything else is dropped and reported in the admin set-up note.
* Banner date window uses the **viewer's local date**. Dismissals are stored in the viewer's browser (`localStorage`), so they don't follow people between devices. Change `dismiss_key` to show a new announcement to everyone.
* Set-up notes are shown to users with `sp_admin` or `admin` only.
* If your instance's SCSS compiler or a strict content policy rejects CSS custom properties, replace each `var(--pc-...)` with a colour value.
