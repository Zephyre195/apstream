# Install a widget

Do this in a **sub-production instance** first, inside an update set (or your scoped application) so you can move or back out the change.

**Role needed:** `admin` or `sp_admin`.

## 1. Create the widget

1. Go to **Service Portal > Widgets** and select **New**.
2. Set **Name** (for example `PC Status timeline`) and **ID** to the widget's ID, for example `pc-status-timeline`. Keep the IDs from this pack if you plan to embed widgets in each other (see `EMBEDDING.md`).
3. Save, then select **Open in Widget Editor**.

## 2. Paste the four code fields

In the Widget Editor, show the HTML Template, CSS - SCSS, Client Script and Server Script panes, then paste:

| File | Field |
|---|---|
| `1_body_html_template.html` | HTML Template |
| `2_css_scss.scss` | CSS - SCSS |
| `3_client_controller.js` | Client Script (replace the default `api.controller` function entirely) |
| `4_server_script.js` | Server Script (replace the default script entirely) |

Save.

## 3. Add the option schema

Either:

* In the Widget Editor, open the menu and select **Edit option schema**, then add each option from `5_option_schema.json` (name, label, type, hint, section), **or**
* Open the widget record form (**Service Portal > Widgets**, open the record) and paste the whole contents of `5_option_schema.json` into the **Option schema** field.

Choice options include their choices in the JSON. Save.

## 4. Put it on a page

1. Open **Service Portal Designer**, choose your page, and drag the widget into a container.
2. Open the instance options (pencil icon) and fill them in. `widgets/<id>/README.md` explains each option; `example_instance_options.json` has ready-made values you can copy.
3. Preview the page as an **admin**: if an option needs fixing, the widget shows a yellow "set-up note" that only `sp_admin` and `admin` users see.
4. Preview again as an **ordinary user** and check the result with the keyboard (Tab, Enter, Esc) and on a phone-width window.

## 5. Theme it (optional)

Each widget's CSS starts with CSS custom properties, for example `--pc-accent`. Override them in your theme or page CSS:

```css
.pc-links, .pc-timeline, .pc-state { --pc-accent: #0b6b5d; }
```

## Remove a widget

1. Remove its instances from your pages (Service Portal Designer), or find them in **Widget Instances** (`sp_instance`) filtered by the widget, and delete them.
2. Delete the widget record.
3. Banner dismissals live in each viewer's browser (`localStorage` keys starting `pc-banner-dismissed:`). They do nothing once the widget is gone.

Capture the removal in an update set if you installed it through one.
