# Potful Service Portal Components v1.0.0

Four original, presentation-focused widgets for **ServiceNow Service Portal**:

| Widget | ID | What it does |
|---|---|---|
| Announcement banner | `pc-announcement-banner` | Info, success, warning or critical message with optional link, date window and dismiss |
| Quick-link cards | `pc-quick-links` | Responsive grid of up to 24 link cards with icons, descriptions and badges |
| Status timeline | `pc-status-timeline` | Vertical or horizontal progress steps (complete, current, upcoming, blocked, skipped) |
| Loading, empty and error states | `pc-state-panel` | Skeleton loader, friendly empty state and error state with retry |

## Start here

1. Open `demo/index.html` in your browser. It runs offline and shows every widget, built from the exact files in this pack. Use the **Playground** to try options before you install anything.
2. Read `docs/INSTALL.md` and install one widget in a **sub-production** instance first.
3. Configure it with the options in `widgets/<id>/README.md`, or copy an example from `example_instance_options.json`.
4. Want a widget inside your own widget? See `docs/EMBEDDING.md`.

## What's in the box

```
widgets/<id>/1_body_html_template.html   -> Widget Editor: HTML Template
widgets/<id>/2_css_scss.scss             -> Widget Editor: CSS - SCSS
widgets/<id>/3_client_controller.js      -> Widget Editor: Client Script
widgets/<id>/4_server_script.js          -> Widget Editor: Server Script
widgets/<id>/5_option_schema.json        -> Option schema
widgets/<id>/example_instance_options.json
widgets/<id>/README.md                   -> options and examples for that widget
demo/index.html                          -> offline demo and playground
docs/                                    -> install, embedding, compatibility, licence, support, changelog
Quick_Start.pdf, MANIFEST.txt
```

## Good to know

* No table queries, no record writes, no outbound calls. Each widget only reads its instance options (or options passed by an embedding widget).
* Content is plain text. Links are limited to `https://`, `http://`, `/path` and `?id=` portal links.
* Built for Service Portal. Not for UI Builder or Next Experience workspaces. Read `docs/COMPATIBILITY_AND_LIMITATIONS.md` before you install: **these widgets have not yet been tested on a live ServiceNow instance.**
* Independent product. Not affiliated with, endorsed by or certified by ServiceNow. ServiceNow is a trademark of ServiceNow, Inc.
