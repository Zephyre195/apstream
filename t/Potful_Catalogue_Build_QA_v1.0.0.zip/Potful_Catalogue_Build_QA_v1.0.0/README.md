# Catalogue Build & QA v1.0.0

An offline app for planning ServiceNow catalogue items and testing them. Describe each item, its variables, rules, approvals and fulfilment tasks; the app checks everything as you type, shows what's left before build, and writes baseline UAT test cases you can record results against.

## Start in 2 minutes

1. Unzip, then double-click **Catalogue_Build_QA.html**. It opens in your browser and needs no internet, login or install.
2. Choose **See the worked examples** to explore a finished project (three items ready to build and one draft with issues), or **Add your first item**.
3. Fix the issues listed at the top of each item until it shows **Ready to build**.
4. Open **Tests**, run each test in your instance and record Pass, Fail or Blocked, the actual result, evidence and any defect.
5. Use **Save file** to keep a project file, **Download tests (CSV)** for Excel or your test tool, and **Print / PDF** for a specification and test plan to share.

## In this download

| File | What it is |
|---|---|
| `Catalogue_Build_QA.html` | The app (one file, works offline) |
| `Worked_examples_project.json` | The worked examples as a project file (also built into the app) |
| `Quick_Start.pdf` | One-page start guide |
| `docs/Implementation_Guide.md` | Turning a finished spec into a build and running UAT |
| `docs/Data_Dictionary.md` | Every field, check and test type |
| `docs/Known_Limitations.md`, `CHANGELOG.md`, `LICENSE.txt`, `SUPPORT.md` | The small print |

## Supported browsers

Current versions of Microsoft Edge, Google Chrome, Firefox and Safari on Windows or macOS. Phones and tablets work for viewing and recording results; a larger screen is easier for writing specifications.

Independent product. Not affiliated with, endorsed by or certified by ServiceNow. ServiceNow is a trademark of ServiceNow, Inc. All example names and data are fictional.
