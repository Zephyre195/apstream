# Known limitations

* The app checks what you type into it. It doesn't connect to, read from or change your ServiceNow instance, and it can't confirm that a build matches the specification.
* Generated tests are a baseline, not a complete test plan. Notifications, reports, integrations, performance and accessibility need your own tests.
* Work is saved in the browser on the device you use (local storage). Clearing browser data or using a private window removes it. Use **Save file** regularly and to move work between computers.
* Rules support one condition each (`is` / `is not`). Describe complex conditions in the help text or split them into several rules.
* One person editing at a time: there is no real-time sharing. Share project files instead.
* Print / PDF uses your browser's print dialog; page breaks and margins depend on the browser.
* Built and tested in Chromium-based browsers; other current browsers are expected to work but haven't been tested for this release.
