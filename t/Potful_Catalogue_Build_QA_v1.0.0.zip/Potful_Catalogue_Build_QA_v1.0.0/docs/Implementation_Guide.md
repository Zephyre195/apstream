# Implementation guide

## 1. Capture the request
For each catalogue item fill in **Details**: an item ID, name, category, an accountable owner, who can request it, the access rule (who can see it), acceptance criteria and what happens on cancellation before and after approval. These become the item's user criteria, description and fulfilment agreement.

## 2. Design the form
Add **Variables** in the order they should appear. Use `lower_snake_case` names (the app checks this) because they become variable names in ServiceNow and are used in scripts, flows and reports. For any field with a validation rule, give one valid and one invalid example: they become test data.

Add **Rules** for show/hide and conditional mandatory behaviour. In ServiceNow these are usually catalog UI policies (prefer them to client scripts where they can do the job). The app checks that the target and condition variables exist.

## 3. Agree approvals and fulfilment
List each **Approval** step with an approver and what happens if it is approved or rejected. Every approval needs a rejection outcome. List fulfilment **Tasks** with an assignment group, what "done" means and, where relevant, an exception route. Use "Depends on" for tasks that wait for another; the app flags unknown and circular dependencies.

## 4. Build
When an item shows **Ready to build**, use **Print / PDF** as the build specification. A typical build order:
1. Catalogue item record, category and user criteria (Available for / Not available for).
2. Variables (and variable sets if shared across items).
3. Catalog UI policies for the rules; client scripts only where a policy can't do it.
4. Approval and fulfilment logic in your flow (Flow Designer or your organisation's standard).
5. Notifications and the requester's view in the portal.

## 5. Test (UAT)
Open **Tests**. Each generated test has steps and an expected result. Run them in a sub-production instance with test users that match "who can request" and someone who shouldn't have access. Record the status, actual result, evidence and defect reference. Results stay attached to their test even if you edit the item.

The generated tests are a baseline. Add checks for notifications, reporting, integrations, accessibility and anything specific to your organisation in your own test tool; **Download tests (CSV)** gives you a starting file.

## 6. Share and hand over
**Save file** produces a `.json` project file you can send to a colleague, keep in your repository, or open on another computer. **Print / PDF** produces the specification, open issues and the test plan with results for sign-off.
