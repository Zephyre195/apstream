# Changelog

## 1.0.0 – 10 November 2026
First release of the app: item details, variables, rules, approvals and tasks with live checks; readiness dashboard; generated UAT tests with results, evidence and defects; CSV export; project files; print / PDF report; worked examples.
