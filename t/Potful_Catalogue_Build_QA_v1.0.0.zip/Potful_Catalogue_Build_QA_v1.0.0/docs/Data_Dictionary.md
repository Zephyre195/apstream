# Data dictionary

## Item details
| Field | Meaning | Checked |
|---|---|---|
| Item ID | Your reference, e.g. CAT-001 | Required; unique across items (not case-sensitive) |
| Item name | Name shown to requesters | Required |
| Category | Catalogue category | – |
| Owner | Accountable team or person | Required |
| Who can request it | People or groups allowed to order | Required |
| Access rule | Who can see it (user criteria) | Required |
| Acceptance criteria | What "done" means for the requester | Required |
| Cancellation behaviour | What happens if cancelled before and after approval | Required |

## Variables
| Field | Checked |
|---|---|
| Variable name | Required; `lower_snake_case` (a–z, 0–9, _), starting with a letter; unique within the item |
| Label (question) | Required |
| Type | Required (Single line text, Multi-line text, Select box, Reference, Yes / No, Checkbox, Date, Date/time, Email, Integer, Attachment, List collector, Label) |
| Mandatory | Yes or No |
| Default value, Help text | – |
| Validation rule | If set, needs a valid example and an invalid example |

## Rules
| Field | Checked |
|---|---|
| Rule type | Show/hide or Mandatory |
| Target variable | Required; must be a variable in this item |
| When variable | Required; must be a variable in this item; can't be the target |
| Operator, Value | `is` / `is not`; value required |

## Approvals
Step name, Approver (required), If approved (required), If rejected (required).

## Tasks
Task ID (required, unique in the item), Task name (required), Assignment group (required), Depends on (must be a task ID in the item; no circular chains), Done when (required), Exception route.

## Generated test types
| Type | Created for |
|---|---|
| Required field | Each mandatory variable |
| Show / hide rule | Each show/hide rule |
| Conditional mandatory | Each mandatory rule |
| Valid input / Invalid input | Each variable with a validation rule and examples |
| Approve path / Reject path | Each approval with an approver (reject needs a rejection outcome) |
| Cancellation | Each item with cancellation behaviour |
| Task assignment | Each task with an assignment group |
| Exception route | Each task with an exception route |
| Access check (manual) | Each item with "who can request it" |

## Test results
Status (Not run, Pass, Fail, Blocked), Actual result, Evidence, Defect, Tester, Date. Stored against a stable test key, so editing text does not lose results. Deleting the variable, rule, approval or task removes its tests.

## Project file
JSON with `app: "catalogue-qa"`, `version`, `name`, `items` and `results`. Imported files are validated and limited in size.
