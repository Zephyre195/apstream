POTFUL TRADEQUOTE APP — v1.0.0

1. Open START_HERE_Open_your_app.pdf.
2. On your phone: scan the QR code, then add the app to your home screen.
3. On a computer: double-click Potful_TradeQuote_App.html. It works offline.

Your data stays in your browser on that device. Use Settings → Download a backup now and then.
Clearing your browser data or using private browsing can erase it, so keep a backup.
The spreadsheet version is in the other download (TradeQuote_v1.2.0.zip).

Planning aid, not professional advice. Questions? Message Potful on Etsy.
